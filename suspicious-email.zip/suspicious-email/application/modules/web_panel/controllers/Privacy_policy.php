<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Privacy_policy extends MX_Controller {

	
	public function index()
	{
		$this->load->view('privacy-policy');
	}
}
