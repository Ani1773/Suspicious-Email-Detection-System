<div class="section featured">
<div class="section-heading">Featured Products</div>

<div class="section-block">
<div class="section-product  grid ">

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/014-224x224.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/013-224x224.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /> </a></div>
    
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">pure-spice-3</a></h4>
		<p class="price">
		₹500
			<span class="price-tax">Ex Tax: ₹500</span>
		</p>
		 <div id="product-43" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[239]" id="input-option239" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="45">1kg
                                (+₹5)
                 </option>
                                <option value="46">5kg
                                (+₹15)
                 </option>
                                <option value="47">10kg
                                (+₹30)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity43" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="43" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-43" onclick="var xqty='input-quantity43';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(43,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/009-224x224.jpg" alt="Orange" title="Orange" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/003-224x224.jpg" alt="Orange" title="Orange" class="img-responsive" /> </a></div>
  </div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Orange</a></h4>
		<p class="price">
		₹10
			<span class="price-tax">Ex Tax: ₹10</span>
		</p>
		 <div id="product-40" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[237]" id="input-option237" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="40">1kg
                                (+₹15)
                 </option>
                                <option value="41">5kg
                                (+₹30)
                 </option>
                                <option value="42">10kg
                                (+₹85)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity40" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="40" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-40" onclick="var xqty='input-quantity40';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(40,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
           <p class="tag">11<br/> % <br/> <i>off</i></p>
      <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/006-224x224.jpg" alt="Apple" title="Apple" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/009-224x224.jpg" alt="Apple" title="Apple" class="img-responsive" /> </a></div>
    
		<div class="saleback"> <span class="sale">sale</span> </div>
	
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Apple</a></h4>
		<p class="price">
		<span class="price-new">₹80</span> <span class="price-old">₹90</span>
			<span class="price-tax">Ex Tax: ₹80</span>
		</p>
		 <div id="product-42" class="product_option"> 

                                <div class="form-group">
              <select name="option[228]" id="input-option228" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="20">250gm
                                (-₹60)
                 </option>
                                <option value="19">1kg
                 </option>
                                <option value="22">5kg
                                (+₹320)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity42" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="42" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-42" onclick="var xqty='input-quantity42';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(42,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
           <p class="tag">20<br/> % <br/> <i>off</i></p>
      <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/003-224x224.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/006-224x224.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /> </a></div>
    
		<div class="saleback"> <span class="sale">sale</span> </div>
	
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Strawberry</a></h4>
		<p class="price">
		<span class="price-new">₹88</span> <span class="price-old">₹110</span>
			<span class="price-tax">Ex Tax: ₹80</span>
		</p>
		 <div id="product-30" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[229]" id="input-option229" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="21">10kg
                                (+₹110)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity30" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="30" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-30" onclick="var xqty='input-quantity30';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(30,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/012-224x224.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/014-224x224.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /> </a></div>
    
		
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Lentilles</a></h4>
		<p class="price">
		₹110
			<span class="price-tax">Ex Tax: ₹100</span>
		</p>
		 <div id="product-41" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[236]" id="input-option236" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="37">250gm
                                (+₹22)
                 </option>
                                <option value="38">1kg
                                (+₹110)
                 </option>
                                <option value="39">5kg
                                (+₹550)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity41" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="41" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-41" onclick="var xqty='input-quantity41';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(41,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/008-224x224.jpg" alt="Banana" title="Banana" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/006-224x224.jpg" alt="Banana" title="Banana" class="img-responsive" /> </a></div>
    
		
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Banana</a></h4>
		<p class="price">
		₹110
			<span class="price-tax">Ex Tax: ₹100</span>
		</p>
		 <div id="product-28" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[230]" id="input-option230" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="23">1kg
                                (+₹11)
                 </option>
                                <option value="24">5kg
                                (+₹55)
                 </option>
                                <option value="25">10kg
                                (+₹110)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity28" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="28" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-28" onclick="var xqty='input-quantity28';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(28,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/013-224x224.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/002-224x224.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /> </a></div>
    
		
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Bikano shahi</a></h4>
		<p class="price">
		₹110
			<span class="price-tax">Ex Tax: ₹100</span>
		</p>
		 <div id="product-36" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[231]" id="input-option231" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="27">5kg
                                (+₹55)
                 </option>
                                <option value="26">10kg
                                (+₹110)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity36" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="36" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-36" onclick="var xqty='input-quantity36';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(36,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
           <p class="tag">10<br/> % <br/> <i>off</i></p>
      <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/010-224x224.jpg" alt="Greps" title="Greps" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/009-224x224.jpg" alt="Greps" title="Greps" class="img-responsive" /> </a></div>
    
		<div class="saleback"> <span class="sale">sale</span> </div>
	
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Greps</a></h4>
		<p class="price">
		<span class="price-new">₹20</span> <span class="price-old">₹22</span>
			<span class="price-tax">Ex Tax: ₹18</span>
		</p>
		 <div id="product-48" class="product_option"> 

                                <div class="form-group">
              <select name="option[240]" id="input-option240" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="49">5kg
                                (+₹55)
                 </option>
                                <option value="48">10kg
                                (+₹11)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity48" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="48" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-48" onclick="var xqty='input-quantity48';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(48,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/007-224x224.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/009-224x224.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /> </a></div>
    
	
</div>
<div class="product-details">
<div class="caption">

	<h4><a href="#">Pineapple</a></h4>
		<p class="price">
		₹110
			<span class="price-tax">Ex Tax: ₹100</span>
		</p>
		 <div id="product-47" class="product_option"> 

                                <div class="form-group required ">
              <select name="option[238]" id="input-option238" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="43">250gm
                                (+₹55)
                 </option>
                                <option value="44">1kg
                                (+₹220)
                 </option>
                              </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">

              <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity47" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="47" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-47" onclick="var xqty='input-quantity47';
  var aqty = parseInt(document.getElementById(xqty).value); addtoCart(47,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>

<div class=" product-items col-xs-4 col-sm-4 col-md-3 col-lg-3">
<div class="product-thumb transition">
     <div class="image">
        <div class="first_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/011-224x224.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /> </a> </div>
    <div class="swap_image"> <a href="#"> <img src="<?php echo base_url('assets/')?>image/cache/catalog/012-224x224.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /> </a></div>
    
		
	
</div>
<div class="product-details">
 <div class="caption">
  <h4><a href="#">Clasic cioclato</a></h4>
		<p class="price">
		₹88
			<span class="price-tax">Ex Tax: ₹80</span>
		</p>
		 <div id="product-31" class="product_option"> 

             <div class="form-group required ">
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                                <option value="30">1kg
                                (+₹6)
                 </option>
                                <option value="31">5kg
                                (+₹55)
                 </option>
                                <option value="32">10kg
                                (+₹550)
                 </option>
               </select>

            </div>
                                                                                                                                    
           <div class="input-group col-xs-12 col-sm-12 button-group">
             <label class="control-label col-sm-2 col-xs-2">Qty</label>

              <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart col-sm-4 pull-right" id="add-cart-31" onclick="var xqty='input-quantity31';
                 var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>

            </div>

            </div>

                </div>
            </div>
          </div>


</div>
</div>
</div>
	<div class="col-sm-12">
	<div class="btn loadmore btn-primary">Load More Products</div>
	<div class="btn nomore btn-primary">No More Products</div>
	</div>

</div>
