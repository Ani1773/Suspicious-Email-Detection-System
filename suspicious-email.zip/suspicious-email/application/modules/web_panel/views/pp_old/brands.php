<?php include 'global/header.php';?>


<style>
   .content-top-breadcumbrands {
    background: #000 url(<?php echo base_url('assets');?>/img/category-banner.jpg)repeat scroll 0 0;
    margin: 0px 0 30px;
    height: 156px;
    overflow: hidden;
}
    
</style>
<div class="content-top-breadcumbrands">

</div>

<div id="product-manufacturer" class="container">
  <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Brand</a></li>
      </ul>
  <div class="row"><aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="section sidebar">
<div class="section-heading"><div class="border"></div>Account</div>   
 <div class="list-group">
    <a href="#" class="list-group-item">Login</a> <a href="#" class="list-group-item">Register</a> <a href="" class="list-group-item">Forgotten Password</a>
   <a href="#" class="list-group-item">My Account</a>
    <a href="#" class="list-group-item">Address Book</a> <a href="#" class="list-group-item">Wish List</a> <a href="" class="list-group-item">Order History</a> <a href="" class="list-group-item">Downloads</a><a href="" class="list-group-item">Recurring payments</a> <a href="" class="list-group-item">Reward Points</a> <a href="" class="list-group-item">Returns</a> <a href="" class="list-group-item">Transactions</a> <a href="" class="list-group-item">Newsletter</a>
  </div>
</div>

  </aside>

                <div id="content" class="col-sm-9">
      <h1>Find Your Favorite Brand</h1>
            <p><strong>Brand Index:</strong>         &nbsp;&nbsp;&nbsp;<a href="#">A</a>         &nbsp;&nbsp;&nbsp;<a href="">C</a>         &nbsp;&nbsp;&nbsp;<a href="">H</a>  </p>
             <div class="manufacturer-list">
	   <div class="manufacturer-heading">A<a id="A"></a></div>
	   <div class="manufacturer-content">
                  <div class="row">         <div class="col-sm-3"><a href="">Apple</a></div>
         </div>
            	  </div>
	  
	  </div>
             <div class="manufacturer-list">
	   <div class="manufacturer-heading">C<a id="C"></a></div>
	   <div class="manufacturer-content">
                  <div class="row">         <div class="col-sm-3"><a href="">Canon</a></div>
         </div>
            	  </div>
	  
	  </div>
             <div class="manufacturer-list">
	   <div class="manufacturer-heading">H<a id="H"></a></div>
	   <div class="manufacturer-content">
                  <div class="row">         <div class="col-sm-3"><a href="">Hewlett-Packard</a></div>
                <div class="col-sm-3"><a href="">HTC</a></div>
         </div>
            	  </div>
	  
	  </div>
                  </div>
    </div>
</div>
<?php include 'global/footer.php';?>