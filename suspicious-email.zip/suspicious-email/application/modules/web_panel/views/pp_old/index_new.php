<?php
include 'global/header.php';?>
<div class="content-top-breadcum">
</div>
<div id="common-home">
<div class="main-slider">
<!---<div id="spinner"></div> -->
<div class="swiper-viewport">
  <div id="slideshow0" class="swiper-container">
    <div class="swiper-wrapper"> 
         <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/aata-hsm.jpg"  class="img-responsive">
        </div>
              <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/kitchenware.jpg"  class="img-responsive">
        </div>
          <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/cosmestics.jpg"  class="img-responsive">
        </div>
     <div class="swiper-slide text-center">
      
        
            <a href="#"><img src="<?php echo base_url('assets/')?>img/hsm1.jpg" alt="iPhone 6" class="img-responsive" /></a></div>
            <div class="swiper-slide text-center">
            <a href="#"><img src="<?php echo base_url('assets/')?>img/hsm3.jpg" alt="iPhone 6" class="img-responsive" /></a></div>
       <div class="swiper-slide text-center">
            <a href="#"><img src="<?php echo base_url('assets/')?>img/big-mart-banner1.jpg" alt="iPhone 6" class="img-responsive" /></a></div>
          
        <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/hyper-super-market3.jpg"  class="img-responsive">
        </div>
        
        <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/hyper-super-market4.jpg"  class="img-responsive">
        </div>
        <div class="swiper-slide  text-center">
             <img src="<?=base_url('assets/');?>img/hyper8.jpg"  class="img-responsive">
        </div>
        
       </div>
  </div>
  <div class="swiper-pagination slideshow0"></div>
  <div class="swiper-pager mainbanner">
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>
</div>
</div>
<script><!--
$('#slideshow0').swiper({
    mode: 'horizontal',
    slidesPerView: 1,
    pagination: '.slideshow0',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    autoplay: 5000,
    autoplayDisableOnInteraction: true,
    loop: true
});
--></script>
<script>
    // Can also be used with $(document).ready()
    $(window).load(function() {     
      $("#spinner").fadeOut("slow");
    }); 
</script>

<div class="container">
 <div class="row">
<div id="content" class="col-sm-12"><div class="breadcrumb"></div>  

<div class="home-subbanner-block  wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="owl-carousel banner-carousel">
<div class="home-subbanner">
<div class="home-img"><a href="#"><img class="leftbanner" src="<?php echo base_url('assets/')?>image/catalog/sub-banner1.jpg" alt="sub-banner1"></a></div>
<div class="cms-desc">
<div class="cms-text1">Get <b>Chana Dal</b></div>
<div class="cms-text2">@ 20$</div>
<div class="cms-text3">Shop for $ 500</div>
</div>
</div>
<div class="home-subbanner">
<div class="home-img"><a href="#"><img class="leftbanner" src="<?php echo base_url('assets/')?>image/catalog/sub-banner2.jpg" alt="sub-banner1"></a></div>
<div class="cms-desc">
<div class="cms-text1">Get <b>California RED</b></div>
<div class="cms-text2">@ 12$</div>
<div class="cms-text3">Shop for $ 200</div>
</div>
</div>
<div class="home-subbanner">
<div class="home-img"><a href="#"><img class="leftbanner" src="<?php echo base_url('assets/')?>image/catalog/sub-banner3.jpg" alt="sub-banner1"></a></div>
<div class="cms-desc">
<div class="cms-text1">Get <b>Chana dal</b></div>
<div class="cms-text2">@ 20$</div>
<div class="cms-text3">Shop for $ 500</div>
</div>
</div>
</div>
</div>


<div class="shipping-outer  wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="shipping-inner">
<div class="heading col-md-3 col-sm-12 col-xs-12">
  <h2>Why choose us?</h2>
</div>
<div class="subtitle-part subtitle-part1 col-md-3 col-sm-4 col-xs-12">
<div class="subtitle-part-inner">
<div class="subtitile">
<div class="subtitle-part-image"></div>  
<div class="subtitile1">On time delivery</div>
<div class="subtitile2">15% back if not able</div>
</div>
</div>
</div>
<div class="subtitle-part subtitle-part2 col-md-3 col-sm-4 col-xs-12">
<div class="subtitle-part-inner">
<div class="subtitile">
<div class="subtitle-part-image"></div>  
<div class="subtitile1">Free delivery</div>
<div class="subtitile2">Order over $ 200</div>
</div>
</div>
</div>
<div class="subtitle-part subtitle-part3 col-md-3 col-sm-4 col-xs-12">
<div class="subtitle-part-inner">
<div class="subtitile">
<div class="subtitle-part-image"></div>  
<div class="subtitile1">Quality assurance</div>
<div class="subtitile2">You can trust us</div>
</div>
</div>
</div>
</div>
</div>
<!---------Start  Featured Products ------------->
 <div class="main-slider">
<!---<div id="spinner"></div> -->
<div class="swiper-viewport">
  <div id="slideshow02" class="swiper-container">
    <div class="swiper-wrapper">      
        <div class="swiper-slide text-center">
            <a href="#"><img src="<?php echo base_url('assets/')?>img/hyper1.jpg" alt="iPhone 6" class="img-responsive" /></a></div>
            <div class="swiper-slide  text-center">
          <img src="<?=base_url('assets/');?>/img/hyper2.jpg" class="img-responsive"> </div>
        <div class="swiper-slide  text-center">
             <img src="<?=base_url('assets/');?>/img/hyper3.jpg"  class="img-responsive">
        </div>
        <div class="swiper-slide  text-center">
             <img src="<?=base_url('assets/');?>/img/hyper4.jpg"  class="img-responsive">
        </div>
       </div>
  </div>
  <div class="swiper-pagination slideshow02"></div>
  <div class="swiper-pager mainbanner">
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>
</div>
</div>
<script><!--
$('#slideshow02').swiper({
    mode: 'horizontal',
    slidesPerView: 1,
    pagination: '.slideshow02',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    autoplay: 5000,
    autoplayDisableOnInteraction: true,
    loop: true
});
--></script>
<!---- End  Featured Products ----------------->
<style>
    .basket{
        margin-left:485px;
    }
</style>
<!--   Start Affiliates Product here -------------->
<div class="category_product section wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
  <div class="row">
    <div class="panel-heading">
      <h4 class="panel-title">Affiliates</h4>
    </div>

    <div class="col-sm-12 right_block">
      <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <p class="tag">11<br/> % <br/> <i>off</i></p>

          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/affiliate.jpg" alt="Apple" title="Apple" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              <span class="price-new">₹80</span> <span class="price-old">₹90</span>
              <span class="price-tax"> ₹80</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('42');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <p class="tag">20<br/> % <br/> <i>off</i></p>
          
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/affiliates1.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              <span class="price-new">₹88</span> <span class="price-old">₹110</span>
              <span class="price-tax"> ₹80</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('30');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#">Pineapple</a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/affiliates2.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('47');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">

          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/affiliates3.jpg" alt="Banana" title="Banana" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('28');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
    </div>
    <div class="col-sm-12">
      <div class="btn btn-primary viewall"><a href="#">View All</a></div>
    </div>
  </div>

  <div class="row">
    <div class="panel-heading">
      <h4 class="panel-title">Pretty Big Sale</h4>
    </div>

    <div class="col-sm-3 productcategory_thumb">
      <img src="<?php echo base_url('assets/')?>image/cache/catalog/a7.jpg" alt="" title="" class="img-thumbnail" />
    </div>
    <div class="col-sm-9 right_block">
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a1.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹88
              <span class="price-tax"> ₹80</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('31');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('31');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('31');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a2.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('41');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a3.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('36');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('36');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('36');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a5.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹500
              <span class="price-tax"> ₹500</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('43');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('43');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('43');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a6.jpg" alt="il-tuo-espresso" title="il-tuo-espresso" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('34');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('34');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('34');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
      <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
        <div class="product-thumb transition">
          <h4><a href="#"></a></h4>
          <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/a7.jpg" alt="Bladen" title="Bladen" class="img-responsive" /></a></div>

          <div class="caption">     
            <p class="price">
              ₹110
              <span class="price-tax"> ₹100</span>
            </p>
          </div>
          <div class="button-group">
            <button type="button" onclick="cart.add('32');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
            <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
            <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
          </div>

        </div>
      </div>
    </div>
    <div class="col-sm-12">
      <div class="btn btn-primary viewall"><a href="#">View All</a></div>
    </div>
  </div>
</div>


<!------   End  Affiliates Product here -------------->

<!---- Our Start Product ----------------->
  <div class="row">
        <div id="content" class="col-sm-12">
          <h1 class="basket">My Smart Basket</h1>
            <div class="row category_thumb">     
             <div class="col-sm-2"><img src="<?php echo base_url('assets/');?>image/cache/catalog/13-281x391.jpg" alt="Grocery &amp; Staples" title="Grocery &amp; Staples" class="img-thumbnail" /></div>
                </div>
   
            
      <div class="filter-product">
        <div class="btn-grid-list">
          <div class="btn-group btn-group-sm">
            <button type="button" id="filter-view" class="btn btn-default filter collapsed" data-target="#ajaxfilter" data-toggle="collapse" title="Refine Search"><i class="fa fa-th-list"></i></button>
            <button type="button" id="grid-view" class="btn btn-default grid" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
            
          </div>
        </div>
        <div class="compare-total"><a href="<?php echo base_url();?>index.php/web_panel/Category" id="compare-total">View More (0)</a></div>
        <div class="filter-product-right text-right">
          <div class="sort-filter">
            <div class="col-xs-4 col-sm-4 col-md-4 text-right">
              <label class="control-label" for="input-sort">Sort By:</label>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 text-right">
              <select id="input-sort" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">Default</option>
                                                            <option value="">Name (A - Z)</option>
                                                            <option value="">Name (Z - A)</option>
                                                            <option value="">Price (Low &gt; High)</option>
                                                            <option value="">Price (High &gt; Low)</option>
                                                            <option value="">Rating (Highest)</option>
                                                            <option value="">Rating (Lowest)</option>
                                                            <option value="">Model (A - Z)</option>
                                                            <option value="">Model (Z - A)</option>
                                            </select>
            </div>
          </div>
          <div class="show-filter">
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <label class="control-label" for="input-limit">Show:</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <select id="input-limit" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">12</option>
                                                           <option value="">25</option>
                                                            <option value="">50</option>
                                                            <option value="">75</option>
                                                            <option value="">100</option>
                                            </select>
            </div>
          </div>
        </div>
      </div>
      <div class="products-collection">
      <div class="row product-layoutrow"> 
     <?php  foreach($product as $pt) {?>
        <div class="product-layout product-list col-xs-12">
          <div class="product-thumb">
            <div class="image">
            <a href=""><img src="<?php echo base_url('uploads/product/'.$pt['image']); ?>" alt="<?php echo $pt['product_name'];?>" title="<?php echo $pt['product_name'];?>" class="img-responsive" /></a>
            </div>
            <div class="product-details">
              <div class="caption">
                 <h4><a href=""><?php echo substr($pt['product_name'],0,15)?></a></h4>    
        <p class="price">  ₹<?php echo $pt['mrp'];?> <span class="price-tax">Ex Tax: ₹5</span>  </p>
     <p class="desc"><?php echo $pt['description'];?></p>
     <div id="product-31" class="product_option">   
            <div class="form-group required ">              
              <label class="control-label">Packet Size</label>
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                <option value="30">
                                (+₹<?php echo $pt['mrp'];?>)
                 </option>
              
                
                </select>
            </div>
            <div class="input-group col-xs-12 col-sm-12 button-group"> 
              <label class="control-label col-sm-2 col-xs-2">Qty</label>
               <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart" id="add-cart-31" onclick="var xqty='input-quantity31';
              var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>
              <button type="button" class="compare pull-right"  onclick="compare.add('31');">
            <i class="fa fa-exchange"></i></button>
            <button type="button" class="wishlist pull-right" onclick="wishlist.add('31');"><i class="fa fa-heart"></i> </button>
            <a class="quickview pull-right" href=""><i class="fa fa-eye"></i></a>
            </div>
              </div>
             </div>
            </div>
          </div>
        </div>
        <?php } ?>

         </div>
      <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
      </div>
            </div>
            </div>
    </div>

<!----- Our End Product---------------->
<!----- Start cleaning and household product---------->
<div class="category_product section wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Cleaning & Household</h4>
</div>

<div class="col-sm-12 right_block">
  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">11<br/> % <br/> <i>off</i></p>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/cleaning.jpg" alt="Apple" title="Apple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹80</span> <span class="price-old">₹90</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('42');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
      </div>
   </div>
  </div>


  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">20<br/> % <br/> <i>off</i></p>
       <div class="image"><a href="#"><img src ="<?php echo base_url('assets/')?>img/winter-fabric.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /></a></div>
       <div class="caption">     
        <p class="price">
          <span class="price-new">₹88</span> <span class="price-old">₹110</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('30');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>


  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/disposal.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('47');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
     <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/freshners.jpg" alt="Banana" title="Banana" class="img-responsive" /></a></div>
     <div class="caption">     
      <p class="price">
        ₹110
        <span class="price-tax"> ₹100</span>
      </p>
    </div>
    <div class="button-group">
      <button type="button" onclick="cart.add('28');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
      <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
      <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
    </div>
  </div>
</div>

</div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>

<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Must Have This Season</h4>
</div>

<div class="col-sm-3 productcategory_thumb">
<img src="<?php echo base_url('assets/')?>image/cache/catalog/m8.jpg" alt="" title="" class="img-thumbnail" />
</div>
<div class="col-sm-9 right_block">

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m7.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹88
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('31');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('31');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('31');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m6.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /></a></div>
        <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('41');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>


  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m4.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('36');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('36');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('36');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m3.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹500
          <span class="price-tax"> ₹500</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('43');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('43');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('43');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>


  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m2.jpg" alt="il-tuo-espresso" title="il-tuo-espresso" class="img-responsive" /></a></div>
       <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('34');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('34');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('34');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/m1.jpg" alt="Bladen" title="Bladen" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('32');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>
</div>

<!----- End cleaning and household product---------->

<!---- Our Start Product ----------------->
  <div class="row">
        <div id="content" class="col-sm-12">
          <h1 class="basket">My Smart Basket</h1>
            <div class="row category_thumb">     
             <div class="col-sm-2"><img src="<?php echo base_url('assets/');?>image/cache/catalog/13-281x391.jpg" alt="Grocery &amp; Staples" title="Grocery &amp; Staples" class="img-thumbnail" /></div>
                </div>
   
            
      <div class="filter-product">
        <div class="btn-grid-list">
          <div class="btn-group btn-group-sm">
            <button type="button" id="filter-view" class="btn btn-default filter collapsed" data-target="#ajaxfilter" data-toggle="collapse" title="Refine Search"><i class="fa fa-th-list"></i></button>
            <button type="button" id="grid-view" class="btn btn-default grid" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
            
          </div>
        </div>
        <div class="compare-total"><a href="<?php echo base_url();?>index.php/web_panel/Category" id="compare-total">View More (0)</a></div>
        <div class="filter-product-right text-right">
          <div class="sort-filter">
            <div class="col-xs-4 col-sm-4 col-md-4 text-right">
              <label class="control-label" for="input-sort">Sort By:</label>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 text-right">
              <select id="input-sort" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">Default</option>
                                                            <option value="">Name (A - Z)</option>
                                                            <option value="">Name (Z - A)</option>
                                                            <option value="">Price (Low &gt; High)</option>
                                                            <option value="">Price (High &gt; Low)</option>
                                                            <option value="">Rating (Highest)</option>
                                                            <option value="">Rating (Lowest)</option>
                                                            <option value="">Model (A - Z)</option>
                                                            <option value="">Model (Z - A)</option>
                                            </select>
            </div>
          </div>
          <div class="show-filter">
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <label class="control-label" for="input-limit">Show:</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <select id="input-limit" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">12</option>
                                                           <option value="">25</option>
                                                            <option value="">50</option>
                                                            <option value="">75</option>
                                                            <option value="">100</option>
                                            </select>
            </div>
          </div>
        </div>
      </div>
      <div class="products-collection">
      <div class="row product-layoutrow"> 


<?php  foreach($product2 as $pt) {?>
        <div class="product-layout product-list col-xs-12">
          <div class="product-thumb">
            <div class="image">
            <a href=""><img src="<?php echo base_url('uploads/product/'.$pt['image']); ?>" alt="<?php echo $pt['product_name'];?>" title="<?php echo $pt['product_name'];?>" class="img-responsive" /></a>
            </div>
            <div class="product-details">
              <div class="caption">
                 <h4><a href=""><?php echo substr($pt['product_name'],0,15)?></a></h4>    
        <p class="price">  ₹<?php echo $pt['mrp'];?> <span class="price-tax">Ex Tax: ₹5</span>  </p>
     <p class="desc"><?php echo $pt['description'];?></p>
     <div id="product-31" class="product_option">   
            <div class="form-group required ">              
              <label class="control-label">Packet Size</label>
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                <option value="30">
                                (+₹<?php echo $pt['mrp'];?>)
                 </option>
              
                
                </select>
            </div>
            <div class="input-group col-xs-12 col-sm-12 button-group"> 
              <label class="control-label col-sm-2 col-xs-2">Qty</label>
               <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart" id="add-cart-31" onclick="var xqty='input-quantity31';
              var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>
              <button type="button" class="compare pull-right"  onclick="compare.add('31');">
            <i class="fa fa-exchange"></i></button>
            <button type="button" class="wishlist pull-right" onclick="wishlist.add('31');"><i class="fa fa-heart"></i> </button>
            <a class="quickview pull-right" href=""><i class="fa fa-eye"></i></a>
            </div>
              </div>
             </div>
            </div>
          </div>
        </div>
        <?php } ?>

         </div>
      <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
      </div>
            </div>
            </div>
    </div>

<!----- Our End Product---------------->
<!-------- Start Snacks Store -------->
<div class="category_product section wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Snacks Store</h4>
</div>

<div class="col-sm-12 right_block">

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">11<br/> % <br/> <i>off</i></p>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/namkeens-chips.jpg" alt="Apple" title="Apple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹80</span> <span class="price-old">₹90</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('42');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">20<br/> % <br/> <i>off</i></p>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/ready-to-cook.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹88</span> <span class="price-old">₹110</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('30');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Pineapple</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/muffin-cupcakes.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('47');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/plumcake-cookie.jpg" alt="Banana" title="Banana" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('28');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>

<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Staples Corner</h4>
</div>
<div class="col-sm-3 productcategory_thumb">
<img src="<?php echo base_url('assets/')?>image/cache/catalog/s1.jpg" alt="" title="" class="img-thumbnail" />
</div>
<div class="col-sm-9 right_block">

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s2.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹88
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('31');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('31');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('31');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s3.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('41');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s4.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('36');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('36');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('36');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s5.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹500
          <span class="price-tax"> ₹500</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('43');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('43');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('43');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s6.jpg" alt="il-tuo-espresso" title="il-tuo-espresso" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('34');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('34');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('34');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/s7.jpg" alt="Bladen" title="Bladen" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('32');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>
</div>

 
<!-------- End Snacks Store -------->

<!---- Our Start Product ----------------->
  <div class="row">
        <div id="content" class="col-sm-12">
          <h1 class="basket">My Smart Basket</h1>
            <div class="row category_thumb">     
             <div class="col-sm-2"><img src="<?php echo base_url('assets/');?>image/cache/catalog/13-281x391.jpg" alt="Grocery &amp; Staples" title="Grocery &amp; Staples" class="img-thumbnail" /></div>
                </div>
   
            
      <div class="filter-product">
        <div class="btn-grid-list">
          <div class="btn-group btn-group-sm">
            <button type="button" id="filter-view" class="btn btn-default filter collapsed" data-target="#ajaxfilter" data-toggle="collapse" title="Refine Search"><i class="fa fa-th-list"></i></button>
            <button type="button" id="grid-view" class="btn btn-default grid" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
            
          </div>
        </div>
        <div class="compare-total"><a href="<?php echo base_url();?>index.php/web_panel/Category" id="compare-total">View More (0)</a></div>
        <div class="filter-product-right text-right">
          <div class="sort-filter">
            <div class="col-xs-4 col-sm-4 col-md-4 text-right">
              <label class="control-label" for="input-sort">Sort By:</label>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 text-right">
              <select id="input-sort" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">Default</option>
                                                            <option value="">Name (A - Z)</option>
                                                            <option value="">Name (Z - A)</option>
                                                            <option value="">Price (Low &gt; High)</option>
                                                            <option value="">Price (High &gt; Low)</option>
                                                            <option value="">Rating (Highest)</option>
                                                            <option value="">Rating (Lowest)</option>
                                                            <option value="">Model (A - Z)</option>
                                                            <option value="">Model (Z - A)</option>
                                            </select>
            </div>
          </div>
          <div class="show-filter">
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <label class="control-label" for="input-limit">Show:</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <select id="input-limit" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">12</option>
                                                           <option value="">25</option>
                                                            <option value="">50</option>
                                                            <option value="">75</option>
                                                            <option value="">100</option>
                                            </select>
            </div>
          </div>
        </div>
      </div>
      <div class="products-collection">
      <div class="row product-layoutrow"> 


<?php  foreach($product3 as $pt) {?>
        <div class="product-layout product-list col-xs-12">
          <div class="product-thumb">
            <div class="image">
            <a href=""><img src="<?php echo base_url('uploads/product/'.$pt['image']); ?>" alt="<?php echo $pt['product_name'];?>" title="<?php echo $pt['product_name'];?>" class="img-responsive" /></a>
            </div>
            <div class="product-details">
              <div class="caption">
                 <h4><a href=""><?php echo substr($pt['product_name'],0,15)?></a></h4>    
        <p class="price">  ₹<?php echo $pt['mrp'];?> <span class="price-tax">Ex Tax: ₹5</span>  </p>
     <p class="desc"><?php echo $pt['description'];?></p>
     <div id="product-31" class="product_option">   
            <div class="form-group required ">              
              <label class="control-label">Packet Size</label>
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                <option value="30">
                                (+₹<?php echo $pt['mrp'];?>)
                 </option>
              
                
                </select>
            </div>
            <div class="input-group col-xs-12 col-sm-12 button-group"> 
              <label class="control-label col-sm-2 col-xs-2">Qty</label>
               <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart" id="add-cart-31" onclick="var xqty='input-quantity31';
              var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>
              <button type="button" class="compare pull-right"  onclick="compare.add('31');">
            <i class="fa fa-exchange"></i></button>
            <button type="button" class="wishlist pull-right" onclick="wishlist.add('31');"><i class="fa fa-heart"></i> </button>
            <a class="quickview pull-right" href=""><i class="fa fa-eye"></i></a>
            </div>
              </div>
             </div>
            </div>
          </div>
        </div>
        <?php } ?>

         </div>
      <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
      </div>
            </div>
            </div>
    </div>

<!----- Our End Product---------------->
<!------------ Start Beauty & Hygiene---------->


<div class="category_product section wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Beauty & Hygiene</h4>
</div>

<div class="col-sm-12 right_block">

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">11<br/> % <br/> <i>off</i></p>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/All_Fragrances.jpg" alt="Apple" title="Apple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹80</span> <span class="price-old">₹90</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('42');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">20<br/> % <br/> <i>off</i></p>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/All_Makeup.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹88</span> <span class="price-old">₹110</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('30');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Pineapple</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/dental-hygiene.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('47');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-3 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>img/bathing-bars-soaps.jpg" alt="Banana" title="Banana" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('28');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

   </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>

<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Grocery &amp; Staples</h4>
</div>

<div class="col-sm-3 productcategory_thumb">
<img src="<?php echo base_url('assets/')?>image/cache/catalog/13-281x391.jpg" alt="" title="" class="img-thumbnail" />
</div>
<div class="col-sm-9 right_block">

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Clasic cioclato</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/06-281x188.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹88
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('31');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('31');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('31');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>


  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Lentilles</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/05-281x188.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('41');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Bikano shahi</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/04-281x188.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('36');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('36');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('36');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">pure-spice-3</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/03-281x188.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹500
          <span class="price-tax"> ₹500</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('43');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('43');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('43');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">il-tuo-espresso</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/02-281x188.jpg" alt="il-tuo-espresso" title="il-tuo-espresso" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('34');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('34');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('34');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Bladen</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/01-281x188.jpg" alt="Bladen" title="Bladen" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('32');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>
</div>

<!------------ End Beauty & Hygiene---------->


<!---- Our Start Product ----------------->
  <div class="row">
        <div id="content" class="col-sm-12">
          <h1 class="basket">My Smart Basket</h1>
            <div class="row category_thumb">     
             <div class="col-sm-2"><img src="<?php echo base_url('assets/');?>image/cache/catalog/13-281x391.jpg" alt="Grocery &amp; Staples" title="Grocery &amp; Staples" class="img-thumbnail" /></div>
                </div>
   
            
      <div class="filter-product">
        <div class="btn-grid-list">
          <div class="btn-group btn-group-sm">
            <button type="button" id="filter-view" class="btn btn-default filter collapsed" data-target="#ajaxfilter" data-toggle="collapse" title="Refine Search"><i class="fa fa-th-list"></i></button>
            <button type="button" id="grid-view" class="btn btn-default grid" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
            
          </div>
        </div>
        <div class="compare-total"><a href="<?php echo base_url();?>index.php/web_panel/Category" id="compare-total">View More (0)</a></div>
        <div class="filter-product-right text-right">
          <div class="sort-filter">
            <div class="col-xs-4 col-sm-4 col-md-4 text-right">
              <label class="control-label" for="input-sort">Sort By:</label>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 text-right">
              <select id="input-sort" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">Default</option>
                                                            <option value="">Name (A - Z)</option>
                                                            <option value="">Name (Z - A)</option>
                                                            <option value="">Price (Low &gt; High)</option>
                                                            <option value="">Price (High &gt; Low)</option>
                                                            <option value="">Rating (Highest)</option>
                                                            <option value="">Rating (Lowest)</option>
                                                            <option value="">Model (A - Z)</option>
                                                            <option value="">Model (Z - A)</option>
                                            </select>
            </div>
          </div>
          <div class="show-filter">
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <label class="control-label" for="input-limit">Show:</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <select id="input-limit" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">12</option>
                                                           <option value="">25</option>
                                                            <option value="">50</option>
                                                            <option value="">75</option>
                                                            <option value="">100</option>
                                            </select>
            </div>
          </div>
        </div>
      </div>
      <div class="products-collection">
      <div class="row product-layoutrow"> 


<?php  foreach($product4 as $pt) {?>
        <div class="product-layout product-list col-xs-12">
          <div class="product-thumb">
            <div class="image">
            <a href=""><img src="<?php echo base_url('uploads/product/'.$pt['image']); ?>" alt="<?php echo $pt['product_name'];?>" title="<?php echo $pt['product_name'];?>" class="img-responsive" /></a>
            </div>
            <div class="product-details">
              <div class="caption">
                 <h4><a href=""><?php echo substr($pt['product_name'],0,15)?></a></h4>    
        <p class="price">  ₹<?php echo $pt['mrp'];?> <span class="price-tax">Ex Tax: ₹5</span>  </p>
     <p class="desc"><?php echo $pt['description'];?></p>
     <div id="product-31" class="product_option">   
            <div class="form-group required ">              
              <label class="control-label">Packet Size</label>
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                <option value="30">
                                (+₹<?php echo $pt['mrp'];?>)
                 </option>
              
                
                </select>
            </div>
            <div class="input-group col-xs-12 col-sm-12 button-group"> 
              <label class="control-label col-sm-2 col-xs-2">Qty</label>
               <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart" id="add-cart-31" onclick="var xqty='input-quantity31';
              var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>
              <button type="button" class="compare pull-right"  onclick="compare.add('31');">
            <i class="fa fa-exchange"></i></button>
            <button type="button" class="wishlist pull-right" onclick="wishlist.add('31');"><i class="fa fa-heart"></i> </button>
            <a class="quickview pull-right" href=""><i class="fa fa-eye"></i></a>
            </div>
              </div>
             </div>
            </div>
          </div>
        </div>
        <?php } ?>

         </div>
      <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
      </div>
            </div>
            </div>
    </div>

<!----- Our End Product---------------->

<!------- Start Fruits store ---------->

<div class="category_product section wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Fruits store</h4>
</div>
<div class="col-sm-3 productcategory_thumb">
<img src="<?php echo base_url('assets/')?>image/cache/catalog/14-281x391.jpg" alt="" title="" class="img-thumbnail" />
</div>
<div class="col-sm-9 right_block">

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">11<br/> % <br/> <i>off</i></p>
      <h4><a href="#">Apple</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/12-281x188.jpg" alt="Apple" title="Apple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹80</span> <span class="price-old">₹90</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('42');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('42');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('42');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">20<br/> % <br/> <i>off</i></p>
      <h4><a href="#">Strawberry</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/11-281x188.jpg" alt="Strawberry" title="Strawberry" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹88</span> <span class="price-old">₹110</span>
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('30');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('30');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('30');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Pineapple</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/10-281x188.jpg" alt="Pineapple" title="Pineapple" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('47');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('47');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('47');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Banana</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/09-281x188.jpg" alt="Banana" title="Banana" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('28');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('28');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('28');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#">Orange</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/08-281x188.jpg" alt="Orange" title="Orange" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹10
          <span class="price-tax"> ₹10</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('40');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('40');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('40');"><i class="fa fa-exchange"></i></button>
      </div>

    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <p class="tag">10<br/> % <br/> <i>off</i></p>
      <h4><a href="#">Greps</a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/07-281x188.jpg" alt="Greps" title="Greps" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          <span class="price-new">₹20</span> <span class="price-old">₹22</span>
          <span class="price-tax"> ₹18</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('48');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('48');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('48');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>

<div class="row">
<div class="panel-heading">
  <h4 class="panel-title">Grocery &amp; Staples</h4>
</div>

<div class="col-sm-3 productcategory_thumb">
<img src="<?php echo base_url('assets/')?>image/cache/catalog/t8.jpg" alt="" title="" class="img-thumbnail" />
</div>
<div class="col-sm-9 right_block">

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t7.jpg" alt="Clasic cioclato" title="Clasic cioclato" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹88
          <span class="price-tax"> ₹80</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('31');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('31');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('31');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t6.jpg" alt="Lentilles" title="Lentilles" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('41');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('41');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('41');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t5.jpg" alt="Bikano shahi" title="Bikano shahi" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('36');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('36');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('36');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t4.jpg" alt="pure-spice-3" title="pure-spice-3" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹500
          <span class="price-tax"> ₹500</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('43');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('43');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('43');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t3.jpg" alt="il-tuo-espresso" title="il-tuo-espresso" class="img-responsive" /></a></div>
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('34');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('34');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('34');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  <div class="product-layout col-lg-4 col-md-4 col-sm-6 col-xs-4">
    <div class="product-thumb transition">
      <h4><a href="#"></a></h4>
      <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/t2.jpg" alt="Bladen" title="Bladen" class="img-responsive" /></a></div>
      
      <div class="caption">     
        <p class="price">
          ₹110
          <span class="price-tax"> ₹100</span>
        </p>
      </div>
      <div class="button-group">
        <button type="button" onclick="cart.add('32');"><i class="fa fa-shopping-cart"></i> <span class="hidden-xs hidden-sm hidden-md">Add</span></button>
        <button type="button" data-toggle="tooltip" title="Wish List" onclick="wishlist.add('32');"><i class="fa fa-heart"></i></button>
        <button type="button" data-toggle="tooltip" title="Compare" onclick="compare.add('32');"><i class="fa fa-exchange"></i></button>
      </div>
    </div>
  </div>

  </div>
  <div class="col-sm-12">
  <div class="btn btn-primary viewall"><a href="#">View All</a></div>
  </div>
</div>
</div>


<!------- End Fruits store ---------->

<!---- Our Start Product ----------------->
  <div class="row">
        <div id="content" class="col-sm-12">
          <h1 class="basket">My Smart Basket</h1>
            <div class="row category_thumb">     
             <div class="col-sm-2"><img src="<?php echo base_url('assets/');?>image/cache/catalog/13-281x391.jpg" alt="Grocery &amp; Staples" title="Grocery &amp; Staples" class="img-thumbnail" /></div>
                </div>
   
            
      <div class="filter-product">
        <div class="btn-grid-list">
          <div class="btn-group btn-group-sm">
            <button type="button" id="filter-view" class="btn btn-default filter collapsed" data-target="#ajaxfilter" data-toggle="collapse" title="Refine Search"><i class="fa fa-th-list"></i></button>
            <button type="button" id="grid-view" class="btn btn-default grid" data-toggle="tooltip" title="Grid"><i class="fa fa-th"></i></button>
            <button type="button" id="list-view" class="btn btn-default list" data-toggle="tooltip" title="List"><i class="fa fa-th-list"></i></button>
            
          </div>
        </div>
        <div class="compare-total"><a href="<?php echo base_url();?>index.php/web_panel/Category" id="compare-total">View More (0)</a></div>
        <div class="filter-product-right text-right">
          <div class="sort-filter">
            <div class="col-xs-4 col-sm-4 col-md-4 text-right">
              <label class="control-label" for="input-sort">Sort By:</label>
            </div>
            <div class="col-xs-8 col-sm-8 col-md-8 text-right">
              <select id="input-sort" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">Default</option>
                                                            <option value="">Name (A - Z)</option>
                                                            <option value="">Name (Z - A)</option>
                                                            <option value="">Price (Low &gt; High)</option>
                                                            <option value="">Price (High &gt; Low)</option>
                                                            <option value="">Rating (Highest)</option>
                                                            <option value="">Rating (Lowest)</option>
                                                            <option value="">Model (A - Z)</option>
                                                            <option value="">Model (Z - A)</option>
                                            </select>
            </div>
          </div>
          <div class="show-filter">
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <label class="control-label" for="input-limit">Show:</label>
            </div>
            <div class="col-xs-6 col-sm-6 col-md-6 text-right">
              <select id="input-limit" class="form-control" onchange="location = this.value;">
                                              <option value="" selected="selected">12</option>
                                                           <option value="">25</option>
                                                            <option value="">50</option>
                                                            <option value="">75</option>
                                                            <option value="">100</option>
                                            </select>
            </div>
          </div>
        </div>
      </div>
      <div class="products-collection">
      <div class="row product-layoutrow"> 


<?php  foreach($product5 as $pt) {?>
        <div class="product-layout product-list col-xs-12">
          <div class="product-thumb">
            <div class="image">
            <a href=""><img src="<?php echo base_url('uploads/product/'.$pt['image']); ?>" alt="<?php echo $pt['product_name'];?>" title="<?php echo $pt['product_name'];?>" class="img-responsive" /></a>
            </div>
            <div class="product-details">
              <div class="caption">
                 <h4><a href=""><?php echo substr($pt['product_name'],0,15)?></a></h4>    
        <p class="price">  ₹<?php echo $pt['mrp'];?> <span class="price-tax">Ex Tax: ₹5</span>  </p>
     <p class="desc"><?php echo $pt['description'];?></p>
     <div id="product-31" class="product_option">   
            <div class="form-group required ">              
              <label class="control-label">Packet Size</label>
              <select name="option[233]" id="input-option233" class="form-control">
                <option value=""> --- Please Select --- </option>
                <option value="30">
                                (+₹<?php echo $pt['mrp'];?>)
                 </option>
              
                
                </select>
            </div>
            <div class="input-group col-xs-12 col-sm-12 button-group"> 
              <label class="control-label col-sm-2 col-xs-2">Qty</label>
               <input type="number" name="quantity" min="1" value="1" size="1" step="1" id="input-quantity31" class="qty form-control col-sm-2 col-xs-9" />
              <input type="hidden" name="product_id" value="31" />
              <button type="button" class="addtocart" id="add-cart-31" onclick="var xqty='input-quantity31';
              var aqty = parseInt(document.getElementById(xqty).value); addtoCart(31,aqty);">Add</button>
              <button type="button" class="compare pull-right"  onclick="compare.add('31');">
            <i class="fa fa-exchange"></i></button>
            <button type="button" class="wishlist pull-right" onclick="wishlist.add('31');"><i class="fa fa-heart"></i> </button>
            <a class="quickview pull-right" href=""><i class="fa fa-eye"></i></a>
            </div>
              </div>
             </div>
            </div>
          </div>
        </div>
        <?php } ?>

         </div>
      <div class="row">
        <div class="col-sm-6 text-left"></div>
        <div class="col-sm-6 text-right">Showing 1 to 4 of 4 (1 Pages)</div>
      </div>
            </div>
            </div>
    </div>

<!----- Our End Product---------------->
<!---------Start  Featured Products ------------->
 <div class="main-slider">
<!---<div id="spinner"></div> -->
<div class="swiper-viewport">
  <div id="slideshow01" class="swiper-container">
    <div class="swiper-wrapper">      
       
            <div class="swiper-slide  text-center">
          <img src="<?=base_url();?>/uploads/banner-slider/hyper-super-markets2.jpg" class="img-responsive"> </div>
        <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/hyper-super-market3.jpg"  class="img-responsive">
        </div>
        <div class="swiper-slide  text-center">
             <img src="<?=base_url();?>/uploads/banner-slider/hyper-super-market4.jpg"  class="img-responsive">
        </div>
       </div>
  </div>
  <div class="swiper-pagination slideshow01"></div>
  <div class="swiper-pager mainbanner">
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
  </div>
</div>
</div>
<script><!--
$('#slideshow01').swiper({
    mode: 'horizontal',
    slidesPerView: 1,
    pagination: '.slideshow01',
    paginationClickable: true,
    nextButton: '.swiper-button-next',
    prevButton: '.swiper-button-prev',
    spaceBetween: 0,
    autoplay: 5000,
    autoplayDisableOnInteraction: true,
    loop: true
});
--></script>
<!---- End  Featured Products ----------------->



<!------- Start Top categories ---------->

<div class="category-banner-block wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<h3>Top categories</h3>
<div class="row">
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Del Monte Beets</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat-1-180x135.png" alt="Del Monte Beets" title="Del Monte Beets" class="img-responsive"/></a></div>       
      </div>
    </div>
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Veggies</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat2-180x135.png" alt="Veggies" title="Veggies" class="img-responsive"/></a></div>       
      </div>
    </div>
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Del Monte Corn</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat3-180x135.png" alt="Del Monte Corn" title="Del Monte Corn" class="img-responsive"/></a></div>       
      </div>
    </div>
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Riced cauliflower</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat4-180x135.png" alt="Riced cauliflower" title="Riced cauliflower" class="img-responsive"/></a></div>       
      </div>
    </div>
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Veggies Bowl</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat5-180x135.png" alt="Veggies Bowl" title="Veggies Bowl" class="img-responsive"/></a></div>       
      </div>
    </div>
      <div class="product-layout col-lg-2 col-md-2 col-sm-4 col-xs-4">
      <div class="product-thumb transition">
         <div class="caption categoryname">
          <h4><a href="#">Green peas | Carrots</a></h4>
        </div>
        <div class="image"><a href="#"><img src="<?php echo base_url('assets/')?>image/cache/catalog/cat6-180x135.png" alt="Green peas | Carrots" title="Green peas | Carrots" class="img-responsive"/></a></div>       
      </div>
    </div>
  </div>
</div>

<!---------End  Top categories ------------->


<!---- Start  Our Popular Brands ----------------->

<div class="section brand wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s">
<div class="section-heading" >Our Popular Brands</div>   
<div class="section-block">
  <div id="carousel0" class="manufacture-slider owl-carousel">
        <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand1.jpg" alt="Coca Cola" class="img-responsive" /></a></div></div>
            <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand2.jpg" alt="Canon" class="img-responsive" /></a></div></div>
            <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand3.jpg" alt="apple" class="img-responsive" /></a></div></div>
            <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand4.jpg" alt="Burger King" class="img-responsive" /></a></div></div>
            <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand5.jpg" alt="RedBull" class="img-responsive" /></a></div></div>
            <div class="product-thumb">
      <div class="item text-center"><a href="#"><img src="<?php echo base_url('assets/')?>img/brand6.jpg" alt="NFL" class="img-responsive" /></a></div></div>
        </div>
  </div>
 </div>
<!--- End  Our Popular Brands------------>

<script><!--

$(document).ready(function(){
$('.manufacture-slider').owlCarousel({
        items: 6,
        autoPlay: true,
        singleItem: false,
        navigation: false,
        pagination: false,
        itemsDesktop : [1199,5],
        itemsDesktopSmall : [991,4],
        itemsTablet : [767,3],
        itemsTabletSmall : [479,2],
        itemsMobile : [360,2]
    });

});
--></script>

</div>
    </div></div>

</div>
<script>
$(document).ready(function(){
$('.product-carousel').owlCarousel({
        items: 5,
        autoPlay: false,
        singleItem: false,
        navigation: true,
        pagination: false,
        itemsDesktop : [1199,4],
        itemsDesktopSmall : [991,3],
        itemsTablet : [767,3],
        itemsTabletSmall : [650,2],
        itemsMobile : [479,1]
    });
   
    $('.banner-carousel').owlCarousel({
        items: 2,
        autoPlay: false,
        singleItem: false,
        navigation: false,
        pagination: true,
        itemsDesktop : [1199,2],
        itemsDesktopSmall : [991,2],
        itemsTablet : [767,2],
        itemsTabletSmall : [479,1],
        itemsMobile : [319,1]
    });
    
});
</script>

  
<?php include 'global/footer.php';?>