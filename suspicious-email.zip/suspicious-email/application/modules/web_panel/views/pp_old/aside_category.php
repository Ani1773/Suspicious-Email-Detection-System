 <aside id="column-left" class="col-sm-3 hidden-xs">
    <div class="sidebar section sidebar_category">
<div class="section-heading"><div class="border"></div>Categories</div>   
  <div class="section-block category_block">    
      <ul class="left-category treeview-list treeview">
                       <li class="expandable">
        <a href="">Grocery &amp; Staples</a>
                       
                  <ul class="menu-dropdown">
                                
            <li>
                                <a href="">Daal &amp; Pulses</a>
                                
                  <ul class="menu-dropdown">
                             <li>
                       <a href="">Arhar</a>
                       </li>
                   <li>
                       <a href="">Masoor</a>
                       </li>
                   <li>
                       <a href="">Moong</a>
                       </li>
                   <li>
                       <a href="">Rajma &amp; Chana</a>
                       </li>
                   <li>
                       <a href="">Urad</a>
                       </li>
                 </ul>
                    </li>
                         
            <li>
                                <a href="">Dry Fruits &amp; Nuts</a>
                                
                  <ul class="menu-dropdown">
                             <li>
                       <a href="">Akhrot &amp; Figs</a>
                       </li>
                   <li>
                       <a href="">Almonds &amp; Cashews</a>
                       </li>
                   <li>
                       <a href="">Nuts &amp; Seeds</a>
                       </li>
                   <li>
                       <a href="">Other Dry Fruits</a>
                       </li>
                 </ul>
                    </li>
                         
            <li>
                                <a href="">Edible Oils</a>
                                
                  <ul class="menu-dropdown">
                             <li>
                       <a href="">Groundnut &amp; Coconut Oil</a>
                       </li>
                   <li>
                       <a href="">Health Oils</a>
                       </li>
                   <li>
                       <a href="">Mustard Oils</a>
                       </li>
                   <li>
                       <a href="">Soyabean Oils</a>
                       </li>
                   <li>
                       <a href="">Sunflower Oils</a>
                       </li>
                 </ul>
                    </li>
                         
            <li>
                                <a href="">Riced cauliflower</a>
                                
                  <ul class="menu-dropdown">
                             <li>
                       <a href="">Basmati</a>
                       </li>
                   <li>
                       <a href="">Millet &amp; Others</a>
                       </li>
                   <li>
                       <a href="">Poha</a>
                       </li>
                   <li>
                       <a href="">Sonamasuri &amp; Kolam</a>
                       </li>
                 </ul>
                    </li>
                     </ul>
            </li>
            <li class="expandable">
        <a href="">Personal Care</a>
                       
                  <ul class="menu-dropdown">
                                
            <li>
                                <a href="">Deos &amp; Perfumes</a>
                                   </li>
                         
            <li>
                                <a href="">Hair Care</a>
                                   </li>
                     </ul>
            </li>
            <li class="expandable">
        <a href="">Biscuits, Snacks &amp; Chocolates</a>
                       
                  <ul class="menu-dropdown">
                                
            <li>
                                <a href="">Biscuits &amp; Cookies</a>
                                   </li>
                         
            <li>
                                <a href="">Chips &amp; Crisps</a>
                                   </li>
                     </ul>
            </li>
            <li class="expandable">
        <a href="">Household Needs</a>
                       
                  <ul class="menu-dropdown">
                                
            <li>
                                <a href="">Cleaning Tools &amp; Brushes</a>
                                   </li>
                         
            <li>
                                <a href="">Home &amp; Car Fresheners</a>
                                   </li>
                     </ul>
            </li>
            <li class="expandable">
        <a href="">Breakfast &amp; Dairy</a>
                       
                  <ul class="menu-dropdown">
                                
            <li>
                                <a href="">Breakfast Cereal &amp; Mixes</a>
                                   </li>
                         
            <li>
                                <a href="">Paneer &amp; Curd</a>
                                   </li>
                     </ul>
            </li>
            <li class="expandable">
        <a href="">Veggies Bowl</a>
                    </li>
            <li class="expandable">
        <a href="">Veggies</a>
                    </li>
            <li class="expandable">
        <a href="">Del Monte Beets</a>
                    </li>
            <li class="expandable">
        <a href="">Del Monte Corn</a>
                    </li>
            <li class="expandable">
        <a href="">Green peas | Carrots</a>
                    </li>
            <li class="expandable">
        <a href="">Fruits store</a>
                    </li>
        </ul>
  </div>
</div>

  </aside>