<?php include 'global/header.php';?>

<style>
   .content-top-breadcumprivacy {
    background: #000 url(<?php echo base_url('assets');?>/img/PRIVACY-POLICY-min-hyper.jpg)repeat scroll 0 0;
    margin: 0px 0 30px;
    height: 156px;
    overflow: hidden;
    background-size: 100% 100%;
    background-repeat: no-repeat;
}
    
</style>

<div class="content-top-breadcumprivacy">

</div>

<div id="information-information" class="container">
  <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Privacy Policy</a></li>
      </ul>
  <div class="row">
<div class="content py-5 mb-3">
<div class="container   ">
    <div class="row">
        <div class="col-md-12">
            <h2>Privacy Policy</h2>
		    <hr>
        </div>
    </div>
	<div class="row">
		<div class="col-md-8">
		    <p class="text-justify"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. nded to Southeast Asia with the launch of CarBay.com, CarBay.ph and Oto.com
		    <br>
		    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
		    </p>
		</div>
		<div class="col-md-4">
		    <img src="https://moatsearch-data.s3.amazonaws.com/creative_screens/ee/e0/e5/eee0e595a64ba750d99397c072d5c2e6.jpg">
		</div>
	</div>
</div>
</div>
    </div>
</div>
<?php include 'global/footer.php';?>