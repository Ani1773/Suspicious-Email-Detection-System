 <div class="list-group">
 <a href="<?php echo base_url();?>index.php/web_panel/Franchise_business" class="list-group-item">Franchise Business</a> 
    <a href="<?php echo base_url();?>index.php/web_panel/Franchise_process" class="list-group-item">Franchise Process</a> 
    <a href="<?php echo base_url();?>index.php/web_panel/Our_team" class="list-group-item">Our Team</a>
   <a href="<?php echo base_url();?>index.php/web_panel/Franchise" class="list-group-item">Apply Franchise</a>
    <a href="<?php echo base_url();?>index.php/web_panel/Contact_us" class="list-group-item">Contact Us</a>
    <a href="<?php echo base_url();?>index.php/web_panel/Career" class="list-group-item">Metro Mart Career</a> 
    <a href="<?php echo base_url();?>index.php/web_panel/Gallery" class="list-group-item">Our Gallery</a>
    <a href="<?php echo base_url();?>index.php/web_panel/Franchise_download" class="list-group-item">Downloads</a>
      <a href="<?php echo base_url();?>index.php/web_panel/Video" class="list-group-item">Our Videos</a>
       <a href="<?php echo base_url();?>index.php/web_panel/Our_business" class="list-group-item">Our Business</a>
        <a href="<?php echo base_url();?>index.php/web_panel/Vision_mission" class="list-group-item">Vision Mission</a>
  </div>