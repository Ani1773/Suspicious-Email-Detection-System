<?php include 'global/header.php';?>


<style>
   .content-top-breadcumdelivery {
    background: #000 url(<?php echo base_url('assets');?>/img/category-banner.jpg)repeat scroll 0 0;
    margin: 0px 0 30px;
    height: 156px;
    overflow: hidden;
}
    
</style>
<div class="content-top-breadcumdelivery">

</div>

<div id="information-information" class="container">
  <ul class="breadcrumb">
        <li><a href="#"><i class="fa fa-home"></i></a></li>
        <li><a href="#">Delivery Information</a></li>
      </ul>
  <div class="row">
      
   <?php include 'aside_category.php';?>

<div id="content" class="col-sm-9">
      <h1>Delivery Information</h1>
      <p>
	Delivery Information</p>
</div>
    </div>
</div>
<?php include 'global/footer.php';?>