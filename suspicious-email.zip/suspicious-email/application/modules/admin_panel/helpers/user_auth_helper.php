<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

  if( !function_exists('say_hello') ) {

    function say_hello( $name = 'world' ) {
      echo 'Hello ' . $name;
    }


  }

?> 
