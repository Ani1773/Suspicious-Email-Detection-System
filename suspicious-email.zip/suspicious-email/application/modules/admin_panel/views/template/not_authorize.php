<section class="error-wrapper">
          <i class="icon-404"></i>
          <h1></h1>
          <h2>Sorry! You dont have permission to access this Page.</h2>
          <p class="">Please Contact Administrator.</p>
      </section>