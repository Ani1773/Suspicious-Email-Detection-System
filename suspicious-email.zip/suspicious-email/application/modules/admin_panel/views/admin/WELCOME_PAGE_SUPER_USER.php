<div class="col-md-12">
  <h2 class="text-center">WELCOME TO <span style="color:#39b5aa;">SUSPICIOUS E-MAIL</span><span style="color:#FF6C60;">&nbsp;ADMIN</span> </h2>
  <br>
</div> 
<div class=" state-overview" style="display:none;">
    <div class="col-lg-3 col-sm-6">
        <section class="panel">
            <div class="symbol terques">
                <i class="fa fa-users"></i>
            </div>
            <div class="value">
                <h1 class="count"><?php echo $total_users; ?></h1>
                <p> Total Users</p>
            </div>
        </section>
    </div>
</div>
<div class=" state-overview" style="display:none;">
    <div class="col-lg-3 col-sm-6">
        <section class="panel">
            <div class="symbol yellow">
                <i class="fa fa-users"></i>
            </div>
            <div class="value">
                <h1 class="count"><?php echo $total_active_users; ?></h1>
                <p>Total Active Users</p>
            </div>
        </section>
    </div>
</div>
<div class=" state-overview" style="display:none;">
    <div class="col-lg-3 col-sm-6">
        <section class="panel">
            <div class="symbol red">
                <i class="fa fa-users"></i>
            </div>
            <div class="value">
                <h1 class="count"><?php echo $total_blocked_users; ?></h1>
                <p>Total Blocked Users</p>
            </div>
        </section>
    </div>
</div>


<div class="clearfix"></div>
