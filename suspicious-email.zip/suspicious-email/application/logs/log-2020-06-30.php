<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-30 00:05:41 --> 404 Page Not Found: /index
ERROR - 2020-06-30 03:03:13 --> 404 Page Not Found: /index
ERROR - 2020-06-30 03:03:19 --> 404 Page Not Found: /index
ERROR - 2020-06-30 04:48:45 --> 404 Page Not Found: /index
ERROR - 2020-06-30 05:28:08 --> 404 Page Not Found: /index
ERROR - 2020-06-30 10:17:34 --> 404 Page Not Found: /index
ERROR - 2020-06-30 10:53:41 --> 404 Page Not Found: /index
ERROR - 2020-06-30 11:23:11 --> 404 Page Not Found: /index
ERROR - 2020-06-30 11:37:57 --> 404 Page Not Found: /index
ERROR - 2020-06-30 12:13:20 --> 404 Page Not Found: /index
ERROR - 2020-06-30 12:51:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-30 19:32:32 --> 404 Page Not Found: /index
ERROR - 2020-06-30 19:32:33 --> 404 Page Not Found: /index
ERROR - 2020-06-30 19:32:33 --> 404 Page Not Found: /index
ERROR - 2020-06-30 19:55:55 --> 404 Page Not Found: /index
ERROR - 2020-06-30 22:54:07 --> 404 Page Not Found: /index
ERROR - 2020-06-30 22:54:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
