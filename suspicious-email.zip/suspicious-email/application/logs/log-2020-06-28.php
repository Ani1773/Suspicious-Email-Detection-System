<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-28 00:34:12 --> 404 Page Not Found: /index
ERROR - 2020-06-28 00:38:09 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-06-28 00:38:17 --> 404 Page Not Found: /index
ERROR - 2020-06-28 00:38:18 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-06-28 00:38:21 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-06-28 00:38:21 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:38:22 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:38:25 --> 404 Page Not Found: /index
ERROR - 2020-06-28 00:38:25 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-06-28 00:38:30 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-06-28 00:38:35 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:38:38 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:38:44 --> 404 Page Not Found: /index
ERROR - 2020-06-28 00:38:49 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:48:03 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT count(id) as total FROM contact where type=0
ERROR - 2020-06-28 00:49:14 --> Query error: Unknown column 'type' in 'where clause' - Invalid query: SELECT * FROM contact where type=0  and status!=2 order by id desc, status asc limit 0 , 50
ERROR - 2020-06-28 00:50:54 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:50:57 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:51:00 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:51:00 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:51:01 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 00:51:02 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-28 01:01:15 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:01:16 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:01:19 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:01:19 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:03:44 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:03:44 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:03:50 --> 404 Page Not Found: /index
ERROR - 2020-06-28 01:03:50 --> 404 Page Not Found: /index
ERROR - 2020-06-28 04:16:38 --> 404 Page Not Found: /index
ERROR - 2020-06-28 04:16:45 --> 404 Page Not Found: /index
ERROR - 2020-06-28 09:26:50 --> 404 Page Not Found: /index
ERROR - 2020-06-28 09:26:53 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-06-28 09:27:01 --> 404 Page Not Found: /index
ERROR - 2020-06-28 09:27:01 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-06-28 09:27:05 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-06-28 09:27:18 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-06-28 03:26:01 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:26:38 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:30:30 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:31:28 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:32:39 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:33:13 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:34:07 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:34:40 --> 404 Page Not Found: /index
ERROR - 2020-06-28 03:35:08 --> 404 Page Not Found: /index
ERROR - 2020-06-28 11:30:09 --> 404 Page Not Found: /index
ERROR - 2020-06-28 02:55:38 --> 404 Page Not Found: /index
ERROR - 2020-06-28 05:55:58 --> 404 Page Not Found: /index
ERROR - 2020-06-28 06:57:11 --> 404 Page Not Found: /index
ERROR - 2020-06-28 14:00:58 --> 404 Page Not Found: /index
ERROR - 2020-06-28 14:00:58 --> 404 Page Not Found: /index
ERROR - 2020-06-28 15:16:48 --> 404 Page Not Found: /index
ERROR - 2020-06-28 15:20:30 --> 404 Page Not Found: /index
ERROR - 2020-06-28 15:20:30 --> 404 Page Not Found: /index
ERROR - 2020-06-28 16:13:06 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:15:29 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:15:37 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:15:44 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:16:07 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:16:15 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:16:42 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:16:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-28 13:17:13 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:17:39 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:18:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-28 13:20:17 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:22:51 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:22:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-28 13:34:27 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:35:19 --> 404 Page Not Found: /index
ERROR - 2020-06-28 13:35:43 --> 404 Page Not Found: /index
ERROR - 2020-06-28 16:53:10 --> 404 Page Not Found: /index
ERROR - 2020-06-28 17:22:48 --> 404 Page Not Found: /index
ERROR - 2020-06-28 19:23:03 --> 404 Page Not Found: /index
ERROR - 2020-06-28 23:17:24 --> 404 Page Not Found: /index
