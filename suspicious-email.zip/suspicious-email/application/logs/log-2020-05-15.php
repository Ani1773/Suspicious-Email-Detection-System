<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-15 01:33:58 --> 404 Page Not Found: /index
ERROR - 2020-05-15 04:27:04 --> 404 Page Not Found: /index
ERROR - 2020-05-15 04:27:07 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-15 07:58:23 --> 404 Page Not Found: /index
ERROR - 2020-05-15 07:58:28 --> 404 Page Not Found: /index
ERROR - 2020-05-15 07:18:29 --> 404 Page Not Found: /index
ERROR - 2020-05-15 08:16:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-15 11:09:29 --> 404 Page Not Found: /index
ERROR - 2020-05-15 16:23:08 --> 404 Page Not Found: /index
ERROR - 2020-05-15 16:48:07 --> 404 Page Not Found: /index
ERROR - 2020-05-15 16:48:11 --> 404 Page Not Found: /index
