<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-03 08:03:41 --> 404 Page Not Found: /index
ERROR - 2020-06-03 08:03:46 --> 404 Page Not Found: /index
ERROR - 2020-06-03 08:37:52 --> 404 Page Not Found: /index
ERROR - 2020-06-03 10:32:47 --> 404 Page Not Found: /index
ERROR - 2020-06-03 22:20:41 --> 404 Page Not Found: /index
ERROR - 2020-06-03 22:21:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-03 22:22:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-03 10:31:25 --> 404 Page Not Found: /index
ERROR - 2020-06-03 21:09:51 --> 404 Page Not Found: /index
ERROR - 2020-06-03 21:32:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-03 12:52:02 --> 404 Page Not Found: /index
ERROR - 2020-06-03 23:55:08 --> 404 Page Not Found: /index
