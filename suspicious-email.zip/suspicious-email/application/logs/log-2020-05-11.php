<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-11 02:41:36 --> 404 Page Not Found: /index
ERROR - 2020-05-11 02:18:31 --> 404 Page Not Found: /index
ERROR - 2020-05-11 07:55:37 --> 404 Page Not Found: /index
ERROR - 2020-05-11 07:55:43 --> 404 Page Not Found: /index
ERROR - 2020-05-11 15:26:25 --> 404 Page Not Found: /index
ERROR - 2020-05-11 03:36:31 --> 404 Page Not Found: /index
ERROR - 2020-05-11 15:14:31 --> 404 Page Not Found: /index
ERROR - 2020-05-11 15:14:54 --> 404 Page Not Found: /index
ERROR - 2020-05-11 21:05:19 --> 404 Page Not Found: /index
ERROR - 2020-05-11 21:58:00 --> 404 Page Not Found: /index
ERROR - 2020-05-11 23:54:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
