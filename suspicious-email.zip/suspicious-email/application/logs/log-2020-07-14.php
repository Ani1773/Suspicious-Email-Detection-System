<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-14 01:38:14 --> 404 Page Not Found: /index
ERROR - 2020-07-14 05:40:39 --> 404 Page Not Found: /index
ERROR - 2020-07-14 08:04:25 --> 404 Page Not Found: /index
ERROR - 2020-07-14 10:00:27 --> 404 Page Not Found: /index
ERROR - 2020-07-14 17:42:01 --> 404 Page Not Found: /index
ERROR - 2020-07-14 17:42:04 --> 404 Page Not Found: /index
ERROR - 2020-07-14 11:55:01 --> 404 Page Not Found: /index
ERROR - 2020-07-14 11:57:32 --> 404 Page Not Found: /index
ERROR - 2020-07-14 11:57:32 --> 404 Page Not Found: /index
ERROR - 2020-07-14 12:53:17 --> 404 Page Not Found: /index
ERROR - 2020-07-14 14:13:40 --> 404 Page Not Found: /index
ERROR - 2020-07-14 16:36:30 --> 404 Page Not Found: /index
ERROR - 2020-07-14 21:26:04 --> 404 Page Not Found: /index
ERROR - 2020-07-14 21:27:20 --> 404 Page Not Found: /index
ERROR - 2020-07-14 18:50:26 --> 404 Page Not Found: /index
ERROR - 2020-07-14 18:50:32 --> 404 Page Not Found: /index
