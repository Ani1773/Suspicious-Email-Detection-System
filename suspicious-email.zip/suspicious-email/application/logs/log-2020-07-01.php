<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-01 02:50:03 --> 404 Page Not Found: /index
ERROR - 2020-07-01 02:45:17 --> 404 Page Not Found: /index
ERROR - 2020-07-01 00:50:00 --> 404 Page Not Found: /index
ERROR - 2020-07-01 07:21:06 --> 404 Page Not Found: /index
ERROR - 2020-07-01 09:04:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-01 23:00:00 --> 404 Page Not Found: /index
ERROR - 2020-07-01 15:19:16 --> 404 Page Not Found: /index
