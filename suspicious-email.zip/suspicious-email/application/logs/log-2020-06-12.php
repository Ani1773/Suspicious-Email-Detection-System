<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-12 00:02:09 --> 404 Page Not Found: /index
ERROR - 2020-06-12 03:54:12 --> 404 Page Not Found: /index
ERROR - 2020-06-12 00:51:50 --> 404 Page Not Found: /index
ERROR - 2020-06-12 01:52:00 --> 404 Page Not Found: /index
ERROR - 2020-06-12 00:55:05 --> 404 Page Not Found: /index
ERROR - 2020-06-12 05:34:06 --> 404 Page Not Found: /index
ERROR - 2020-06-12 08:21:41 --> 404 Page Not Found: /index
ERROR - 2020-06-12 12:02:20 --> 404 Page Not Found: /index
ERROR - 2020-06-12 14:24:56 --> 404 Page Not Found: /index
ERROR - 2020-06-12 02:29:41 --> 404 Page Not Found: /index
ERROR - 2020-06-12 12:57:59 --> 404 Page Not Found: /index
ERROR - 2020-06-12 16:11:02 --> 404 Page Not Found: /index
ERROR - 2020-06-12 16:11:13 --> 404 Page Not Found: /index
ERROR - 2020-06-12 18:22:20 --> 404 Page Not Found: /index
ERROR - 2020-06-12 14:15:40 --> 404 Page Not Found: /index
ERROR - 2020-06-12 23:55:02 --> 404 Page Not Found: /index
ERROR - 2020-06-12 19:30:34 --> 404 Page Not Found: /index
ERROR - 2020-06-12 20:57:34 --> 404 Page Not Found: /index
