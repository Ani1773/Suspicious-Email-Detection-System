<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-24 02:23:58 --> 404 Page Not Found: /index
ERROR - 2020-02-24 07:57:22 --> 404 Page Not Found: /index
ERROR - 2020-02-24 07:57:24 --> 404 Page Not Found: /index
ERROR - 2020-02-24 07:57:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 07:57:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 07:58:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:01:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:01:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:01:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:01:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:14:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:14:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:14:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:14:38 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:18:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:24:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 08:25:12 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-02-24 08:25:18 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:25:18 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-02-24 08:27:36 --> Severity: error --> Exception: syntax error, unexpected '?>' /home/hyperpla/public_html/hypersupermarket.in/application/modules/admin_panel/views/template/SIDEBAR_SUPER_USER.php 210
ERROR - 2020-02-24 08:28:40 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-02-24 08:29:30 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-02-24 08:30:14 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-02-24 08:30:27 --> 404 Page Not Found: ../modules/admin_panel/controllers/News/img
ERROR - 2020-02-24 08:30:34 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:30:35 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:30:35 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:30:35 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:30:50 --> 404 Page Not Found: /index
ERROR - 2020-02-24 08:30:51 --> 404 Page Not Found: ../modules/admin_panel/controllers/Features/img
ERROR - 2020-02-24 08:31:02 --> 404 Page Not Found: ../modules/admin_panel/controllers/Mail/img
ERROR - 2020-02-24 08:33:46 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-02-24 08:33:47 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-02-24 08:33:49 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-02-24 08:34:37 --> 404 Page Not Found: ../modules/admin_panel/controllers/Profile/img
ERROR - 2020-02-24 01:58:14 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:15 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:16 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:17 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:18 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:19 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:19 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:20 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:21 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:22 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:23 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:24 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:25 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:26 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:26 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:27 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:28 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:28 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:29 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:30 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:31 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:32 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:32 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:33 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:34 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:34 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:35 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:36 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:37 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:37 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:39 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:39 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:40 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:41 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:42 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:42 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:44 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:44 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:45 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:46 --> 404 Page Not Found: /index
ERROR - 2020-02-24 01:58:47 --> 404 Page Not Found: /index
ERROR - 2020-02-24 02:12:44 --> 404 Page Not Found: /index
ERROR - 2020-02-24 10:19:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 16:07:19 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:41 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:41 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:41 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:42 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 02:38:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 05:38:44 --> 404 Page Not Found: /index
ERROR - 2020-02-24 16:14:46 --> 404 Page Not Found: /index
ERROR - 2020-02-24 16:14:47 --> 404 Page Not Found: /index
ERROR - 2020-02-24 16:34:19 --> 404 Page Not Found: /index
ERROR - 2020-02-24 03:59:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 07:06:29 --> 404 Page Not Found: /index
ERROR - 2020-02-24 17:37:16 --> 404 Page Not Found: /index
ERROR - 2020-02-24 07:42:01 --> 404 Page Not Found: /index
ERROR - 2020-02-24 07:06:43 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:41 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:45 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:46 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:46 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:47 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:47 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:48 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:48 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:49 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:49 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:49 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:50 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:50 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:51 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:51 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:52 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:52 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:52 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:42:53 --> 404 Page Not Found: /index
ERROR - 2020-02-24 18:56:01 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:25:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-02-24 19:01:47 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:52 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:52 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:53 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:54 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:54 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:55 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:55 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:56 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:56 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:57 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:57 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:58 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:59 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:01:59 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:02:00 --> 404 Page Not Found: /index
ERROR - 2020-02-24 19:02:00 --> 404 Page Not Found: /index
ERROR - 2020-02-24 17:07:28 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:02:32 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:02:37 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:02:37 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:02:38 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:02:38 --> 404 Page Not Found: /index
ERROR - 2020-02-24 23:37:40 --> 404 Page Not Found: /index
ERROR - 2020-02-24 21:27:54 --> 404 Page Not Found: /index
