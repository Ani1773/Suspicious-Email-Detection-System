<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-04 16:55:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-04 14:37:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-04 23:43:18 --> 404 Page Not Found: /index
ERROR - 2020-04-04 23:43:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-04 23:45:50 --> 404 Page Not Found: /index
ERROR - 2020-04-04 23:45:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-04 23:46:06 --> 404 Page Not Found: /index
ERROR - 2020-04-04 23:54:21 --> 404 Page Not Found: /index
