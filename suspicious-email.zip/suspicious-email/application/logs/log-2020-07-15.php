<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-15 06:41:20 --> 404 Page Not Found: /index
ERROR - 2020-07-15 01:37:02 --> 404 Page Not Found: /index
ERROR - 2020-07-15 01:26:27 --> 404 Page Not Found: /index
ERROR - 2020-07-15 07:52:33 --> 404 Page Not Found: /index
ERROR - 2020-07-15 09:01:35 --> 404 Page Not Found: /index
ERROR - 2020-07-15 20:23:09 --> 404 Page Not Found: /index
ERROR - 2020-07-15 13:23:00 --> 404 Page Not Found: /index
ERROR - 2020-07-15 13:23:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-15 22:55:52 --> 404 Page Not Found: /index
ERROR - 2020-07-15 23:44:02 --> 404 Page Not Found: /index
