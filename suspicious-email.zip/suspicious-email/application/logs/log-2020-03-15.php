<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-15 03:30:26 --> 404 Page Not Found: /index
ERROR - 2020-03-15 03:32:47 --> 404 Page Not Found: /index
ERROR - 2020-03-15 03:37:19 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:07:43 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:17:06 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:17:06 --> 404 Page Not Found: /index
ERROR - 2020-03-15 09:54:45 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:53:30 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:53:33 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Login.php 41
ERROR - 2020-03-15 10:24:35 --> 404 Page Not Found: /index
ERROR - 2020-03-15 04:56:05 --> 404 Page Not Found: /index
ERROR - 2020-03-15 10:26:36 --> 404 Page Not Found: /index
ERROR - 2020-03-15 10:28:06 --> Query error: Unknown column 'mobile' in 'where clause' - Invalid query: SELECT *
FROM `master_register`
WHERE   (
`email` = 'sunil@gmail.com'
OR `mobile` IS NULL
 )
AND `password` = '25d55ad283aa400af464c76d713c07ad'
ERROR - 2020-03-15 05:00:08 --> 404 Page Not Found: /index
ERROR - 2020-03-15 05:11:14 --> Severity: error --> Exception: syntax error, unexpected '}' /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 111
ERROR - 2020-03-15 05:12:36 --> 404 Page Not Found: /index
ERROR - 2020-03-15 05:12:41 --> Severity: error --> Exception: Call to undefined function delete_cookie() /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Login.php 67
ERROR - 2020-03-15 05:18:09 --> 404 Page Not Found: /index
ERROR - 2020-03-15 05:18:17 --> 404 Page Not Found: /index
ERROR - 2020-03-15 05:22:05 --> 404 Page Not Found: /index
ERROR - 2020-03-15 06:13:03 --> 404 Page Not Found: /index
ERROR - 2020-03-15 07:21:54 --> 404 Page Not Found: /index
ERROR - 2020-03-15 07:21:56 --> 404 Page Not Found: /index
ERROR - 2020-03-15 07:22:23 --> 404 Page Not Found: /index
ERROR - 2020-03-15 07:22:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 07:37:27 --> 404 Page Not Found: /index
ERROR - 2020-03-15 07:37:27 --> 404 Page Not Found: /index
ERROR - 2020-03-15 08:58:05 --> 404 Page Not Found: /index
ERROR - 2020-03-15 10:29:17 --> 404 Page Not Found: /index
ERROR - 2020-03-15 10:29:18 --> 404 Page Not Found: /index
ERROR - 2020-03-15 10:37:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 12:07:04 --> 404 Page Not Found: /index
ERROR - 2020-03-15 12:43:49 --> 404 Page Not Found: /index
ERROR - 2020-03-15 13:10:36 --> 404 Page Not Found: /index
ERROR - 2020-03-15 13:22:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 13:46:59 --> 404 Page Not Found: /index
ERROR - 2020-03-15 13:48:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 14:24:41 --> 404 Page Not Found: /index
ERROR - 2020-03-15 14:59:33 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:07:48 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:07:53 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:07:55 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:07:57 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:07:59 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:08:01 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:13:50 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:22:40 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:12 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:15 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:19 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:21 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:23 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:24 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:33:26 --> 404 Page Not Found: /index
ERROR - 2020-03-15 16:37:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 16:42:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 16:42:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 16:59:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 17:30:57 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:01 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:03 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:08 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:10 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:12 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:14 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:16 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:18 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:20 --> 404 Page Not Found: /index
ERROR - 2020-03-15 17:31:25 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:31:11 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:36:27 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:39:59 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:40:02 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:40:05 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:40:08 --> 404 Page Not Found: /index
ERROR - 2020-03-15 18:40:46 --> 404 Page Not Found: /index
ERROR - 2020-03-15 19:02:14 --> 404 Page Not Found: /index
ERROR - 2020-03-15 19:42:45 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:41 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:44 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:47 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:51 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:53 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:55 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:57 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:24:59 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:25:01 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:25:02 --> 404 Page Not Found: /index
ERROR - 2020-03-15 20:25:07 --> 404 Page Not Found: /index
ERROR - 2020-03-15 21:43:59 --> 404 Page Not Found: /index
ERROR - 2020-03-15 22:24:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-15 22:40:10 --> 404 Page Not Found: /index
ERROR - 2020-03-15 23:32:59 --> 404 Page Not Found: /index
