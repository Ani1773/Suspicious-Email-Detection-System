<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-10 01:45:53 --> 404 Page Not Found: /index
ERROR - 2020-06-10 04:13:54 --> 404 Page Not Found: /index
ERROR - 2020-06-10 08:05:22 --> 404 Page Not Found: /index
ERROR - 2020-06-10 08:05:33 --> 404 Page Not Found: /index
ERROR - 2020-06-10 10:28:14 --> 404 Page Not Found: /index
ERROR - 2020-06-10 12:28:50 --> 404 Page Not Found: /index
ERROR - 2020-06-10 00:07:55 --> 404 Page Not Found: /index
ERROR - 2020-06-10 09:23:52 --> 404 Page Not Found: /index
ERROR - 2020-06-10 19:51:50 --> 404 Page Not Found: /index
ERROR - 2020-06-10 19:54:07 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-10 16:30:47 --> 404 Page Not Found: /index
ERROR - 2020-06-10 20:06:05 --> 404 Page Not Found: /index
ERROR - 2020-06-10 13:34:48 --> 404 Page Not Found: /index
ERROR - 2020-06-10 17:15:37 --> 404 Page Not Found: /index
ERROR - 2020-06-10 17:51:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-10 21:06:29 --> 404 Page Not Found: /index
