<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-25 01:16:09 --> 404 Page Not Found: /index
ERROR - 2020-06-25 06:20:38 --> 404 Page Not Found: /index
ERROR - 2020-06-25 18:00:50 --> 404 Page Not Found: /index
ERROR - 2020-06-25 21:18:26 --> 404 Page Not Found: /index
