<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-23 01:44:03 --> 404 Page Not Found: /index
ERROR - 2020-06-23 01:44:04 --> 404 Page Not Found: /index
ERROR - 2020-06-23 07:36:26 --> 404 Page Not Found: /index
ERROR - 2020-06-23 07:36:29 --> 404 Page Not Found: /index
ERROR - 2020-06-23 03:49:20 --> 404 Page Not Found: /index
ERROR - 2020-06-23 04:45:14 --> 404 Page Not Found: /index
ERROR - 2020-06-23 06:05:50 --> 404 Page Not Found: /index
ERROR - 2020-06-23 06:26:14 --> 404 Page Not Found: /index
ERROR - 2020-06-23 14:00:47 --> 404 Page Not Found: /index
ERROR - 2020-06-23 14:00:49 --> 404 Page Not Found: /index
ERROR - 2020-06-23 14:02:21 --> 404 Page Not Found: /index
ERROR - 2020-06-23 09:28:10 --> 404 Page Not Found: /index
ERROR - 2020-06-23 09:28:26 --> 404 Page Not Found: /index
ERROR - 2020-06-23 10:27:11 --> 404 Page Not Found: /index
ERROR - 2020-06-23 11:23:02 --> 404 Page Not Found: /index
ERROR - 2020-06-23 18:54:30 --> 404 Page Not Found: /index
ERROR - 2020-06-23 18:54:30 --> 404 Page Not Found: /index
ERROR - 2020-06-23 18:54:31 --> 404 Page Not Found: /index
ERROR - 2020-06-23 13:08:41 --> 404 Page Not Found: /index
ERROR - 2020-06-23 14:40:26 --> 404 Page Not Found: /index
ERROR - 2020-06-23 23:43:50 --> 404 Page Not Found: /index
ERROR - 2020-06-23 23:43:52 --> 404 Page Not Found: /index
