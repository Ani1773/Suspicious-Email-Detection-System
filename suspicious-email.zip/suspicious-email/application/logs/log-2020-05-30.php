<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-30 00:10:23 --> 404 Page Not Found: /index
ERROR - 2020-05-30 01:05:50 --> 404 Page Not Found: /index
ERROR - 2020-05-30 07:59:23 --> 404 Page Not Found: /index
ERROR - 2020-05-30 07:59:28 --> 404 Page Not Found: /index
ERROR - 2020-05-30 00:14:18 --> 404 Page Not Found: /index
ERROR - 2020-05-30 13:34:28 --> 404 Page Not Found: /index
ERROR - 2020-05-30 05:49:31 --> 404 Page Not Found: /index
ERROR - 2020-05-30 18:53:09 --> 404 Page Not Found: /index
ERROR - 2020-05-30 12:38:28 --> 404 Page Not Found: /index
ERROR - 2020-05-30 15:22:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
