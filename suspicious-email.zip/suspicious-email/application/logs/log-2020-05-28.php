<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-28 01:30:37 --> 404 Page Not Found: /index
ERROR - 2020-05-28 03:39:47 --> 404 Page Not Found: /index
ERROR - 2020-05-28 07:57:25 --> 404 Page Not Found: /index
ERROR - 2020-05-28 07:57:31 --> 404 Page Not Found: /index
ERROR - 2020-05-28 03:42:00 --> 404 Page Not Found: /index
ERROR - 2020-05-28 07:43:33 --> 404 Page Not Found: /index
ERROR - 2020-05-28 09:38:54 --> 404 Page Not Found: /index
ERROR - 2020-05-28 12:38:56 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-28 20:15:46 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:47 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:48 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:49 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:49 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:49 --> 404 Page Not Found: /index
ERROR - 2020-05-28 20:15:50 --> 404 Page Not Found: /index
ERROR - 2020-05-28 10:35:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-28 15:40:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-28 16:20:44 --> 404 Page Not Found: /index
