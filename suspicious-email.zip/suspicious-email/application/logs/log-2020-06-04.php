<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-04 08:02:52 --> 404 Page Not Found: /index
ERROR - 2020-06-04 08:02:58 --> 404 Page Not Found: /index
ERROR - 2020-06-04 16:37:06 --> 404 Page Not Found: /index
ERROR - 2020-06-04 04:09:27 --> 404 Page Not Found: /index
ERROR - 2020-06-04 22:06:30 --> 404 Page Not Found: /index
