<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-23 01:27:17 --> 404 Page Not Found: /index
ERROR - 2020-05-23 07:57:27 --> 404 Page Not Found: /index
ERROR - 2020-05-23 07:57:33 --> 404 Page Not Found: /index
ERROR - 2020-05-23 02:23:14 --> 404 Page Not Found: /index
ERROR - 2020-05-23 13:45:55 --> 404 Page Not Found: /index
ERROR - 2020-05-23 13:45:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-23 13:32:57 --> 404 Page Not Found: /index
ERROR - 2020-05-23 13:40:48 --> 404 Page Not Found: /index
ERROR - 2020-05-23 05:29:29 --> 404 Page Not Found: /index
ERROR - 2020-05-23 21:23:55 --> 404 Page Not Found: /index
ERROR - 2020-05-23 21:23:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
