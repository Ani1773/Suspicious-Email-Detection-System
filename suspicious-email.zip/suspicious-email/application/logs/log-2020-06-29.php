<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-29 01:21:28 --> 404 Page Not Found: /index
ERROR - 2020-06-29 01:21:29 --> 404 Page Not Found: /index
ERROR - 2020-06-29 01:23:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-29 01:23:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-29 01:24:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-29 01:25:01 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-06-29 01:25:06 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-06-29 02:10:20 --> 404 Page Not Found: /index
ERROR - 2020-06-29 02:18:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-29 03:33:21 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-06-29 03:33:33 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:33:33 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-06-29 03:33:41 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-06-29 03:33:45 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:33:45 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-06-29 03:33:55 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:33:56 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-06-29 03:34:06 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:34:11 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:34:11 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-06-29 03:34:20 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:34:21 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-06-29 03:34:28 --> 404 Page Not Found: /index
ERROR - 2020-06-29 03:34:28 --> 404 Page Not Found: ../modules/admin_panel/controllers/Work_culture/img
ERROR - 2020-06-29 03:34:40 --> 404 Page Not Found: ../modules/admin_panel/controllers/Gallery/img
ERROR - 2020-06-29 03:34:58 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-06-29 00:43:34 --> 404 Page Not Found: /index
ERROR - 2020-06-29 07:57:37 --> 404 Page Not Found: /index
ERROR - 2020-06-29 08:26:52 --> 404 Page Not Found: /index
ERROR - 2020-06-29 01:37:55 --> 404 Page Not Found: /index
ERROR - 2020-06-29 04:38:13 --> 404 Page Not Found: /index
ERROR - 2020-06-29 07:19:28 --> 404 Page Not Found: /index
ERROR - 2020-06-29 09:50:38 --> 404 Page Not Found: /index
ERROR - 2020-06-29 09:51:07 --> 404 Page Not Found: /index
ERROR - 2020-06-29 10:42:07 --> 404 Page Not Found: /index
ERROR - 2020-06-29 10:42:07 --> 404 Page Not Found: /index
ERROR - 2020-06-29 18:42:16 --> 404 Page Not Found: /index
ERROR - 2020-06-29 14:33:40 --> 404 Page Not Found: /index
ERROR - 2020-06-29 16:28:56 --> 404 Page Not Found: /index
ERROR - 2020-06-29 18:29:29 --> 404 Page Not Found: /index
ERROR - 2020-06-29 20:28:24 --> 404 Page Not Found: /index
ERROR - 2020-06-29 21:52:02 --> 404 Page Not Found: /index
ERROR - 2020-06-29 21:52:02 --> 404 Page Not Found: /index
ERROR - 2020-06-29 21:56:03 --> 404 Page Not Found: /index
ERROR - 2020-06-29 22:23:05 --> 404 Page Not Found: /index
ERROR - 2020-06-29 22:48:16 --> 404 Page Not Found: /index
ERROR - 2020-06-29 23:00:41 --> 404 Page Not Found: /index
ERROR - 2020-06-29 23:00:46 --> 404 Page Not Found: /index
ERROR - 2020-06-29 23:00:46 --> 404 Page Not Found: /index
ERROR - 2020-06-29 21:20:32 --> 404 Page Not Found: /index
