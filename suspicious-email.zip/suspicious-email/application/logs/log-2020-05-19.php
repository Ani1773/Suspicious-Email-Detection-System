<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-19 01:48:44 --> 404 Page Not Found: /index
ERROR - 2020-05-19 07:58:38 --> 404 Page Not Found: /index
ERROR - 2020-05-19 07:58:44 --> 404 Page Not Found: /index
ERROR - 2020-05-19 06:35:14 --> 404 Page Not Found: /index
ERROR - 2020-05-19 01:49:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 10:08:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 03:21:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 17:41:29 --> 404 Page Not Found: /index
ERROR - 2020-05-19 06:27:14 --> 404 Page Not Found: /index
ERROR - 2020-05-19 13:18:28 --> 404 Page Not Found: /index
ERROR - 2020-05-19 10:38:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 10:38:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 23:36:33 --> 404 Page Not Found: /index
ERROR - 2020-05-19 23:36:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 14:12:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-19 21:36:35 --> 404 Page Not Found: /index
