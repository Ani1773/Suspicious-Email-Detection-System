<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-24 07:58:10 --> 404 Page Not Found: /index
ERROR - 2020-05-24 07:58:16 --> 404 Page Not Found: /index
ERROR - 2020-05-24 08:30:38 --> 404 Page Not Found: /index
ERROR - 2020-05-24 04:00:01 --> 404 Page Not Found: /index
ERROR - 2020-05-24 04:00:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-24 09:48:50 --> 404 Page Not Found: /index
ERROR - 2020-05-24 21:18:10 --> 404 Page Not Found: /index
ERROR - 2020-05-24 21:18:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-24 17:53:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
