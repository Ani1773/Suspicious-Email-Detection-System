<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-01 00:21:28 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:23 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:25 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:25 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:26 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:27 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:27 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:27 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:28 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:28 --> 404 Page Not Found: /index
ERROR - 2020-04-01 01:36:28 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:18 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:20 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:20 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:20 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:20 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:12:21 --> 404 Page Not Found: /index
ERROR - 2020-04-01 02:41:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 02:41:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 03:30:31 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:30:33 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:30:33 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:41 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:42 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:43 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:45 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:45 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:45 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 03:40:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:04:43 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:04:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:04:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:45:59 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:46:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:46:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 04:51:43 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 04:51:52 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 04:52:18 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 04:52:22 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 04:52:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 04:52:54 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 04:54:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 05:10:55 --> 404 Page Not Found: /index
ERROR - 2020-04-01 05:11:34 --> 404 Page Not Found: /index
ERROR - 2020-04-01 05:13:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 05:13:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 05:41:18 --> 404 Page Not Found: /index
ERROR - 2020-04-01 06:00:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 06:00:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 06:00:56 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 06:10:57 --> 404 Page Not Found: /index
ERROR - 2020-04-01 06:23:41 --> 404 Page Not Found: /index
ERROR - 2020-04-01 07:42:51 --> 404 Page Not Found: /index
ERROR - 2020-04-01 07:42:53 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:05:40 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:05:42 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:14:39 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:14:49 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:14:52 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:14:58 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:14:59 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:15:00 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:15:01 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:15:02 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:15:03 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:15:04 --> 404 Page Not Found: /index
ERROR - 2020-04-01 08:24:49 --> 404 Page Not Found: /index
ERROR - 2020-04-01 09:29:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 09:29:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 09:31:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 09:51:09 --> 404 Page Not Found: /index
ERROR - 2020-04-01 09:51:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 09:51:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 10:10:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 10:13:01 --> 404 Page Not Found: /index
ERROR - 2020-04-01 10:35:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 10:38:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 10:43:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 10:43:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:01:56 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:01:59 --> 404 Page Not Found: /index
ERROR - 2020-04-01 11:24:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:24:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:24:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:28:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 11:33:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 11:38:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:38:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 11:47:15 --> 404 Page Not Found: /index
ERROR - 2020-04-01 11:47:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 12:12:35 --> 404 Page Not Found: /index
ERROR - 2020-04-01 12:27:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 12:27:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 12:27:25 --> 404 Page Not Found: /index
ERROR - 2020-04-01 12:58:18 --> 404 Page Not Found: /index
ERROR - 2020-04-01 13:35:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:08:24 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:08:25 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:08:25 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:09:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:09:11 --> 404 Page Not Found: /index
ERROR - 2020-04-01 14:37:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 14:37:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 14:37:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 14:37:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 15:11:40 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:11:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 15:20:42 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:21:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 15:22:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 15:22:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 15:25:04 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:07 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:07 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:09 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:09 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:11 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:11 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:11 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:12 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:12 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:12 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:25:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 15:28:22 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:02:50 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:15:23 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:15:24 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:15:24 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:15:27 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:54:33 --> 404 Page Not Found: /index
ERROR - 2020-04-01 16:57:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 17:18:21 --> 404 Page Not Found: /index
ERROR - 2020-04-01 17:19:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:20:15 --> 404 Page Not Found: /index
ERROR - 2020-04-01 17:21:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:22:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:22:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:22:36 --> 404 Page Not Found: /index
ERROR - 2020-04-01 17:25:07 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:26:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:28:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:34:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:35:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:41:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 17:44:34 --> 404 Page Not Found: /index
ERROR - 2020-04-01 17:46:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:00:49 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:04:29 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:06:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:16:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:17:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:34:42 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:39:36 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:42:14 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:43:21 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:43:21 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:43:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:48:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:48:40 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:48:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:48:47 --> 404 Page Not Found: /index
ERROR - 2020-04-01 18:48:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:49:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:49:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:50:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:50:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:51:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:51:33 --> Severity: error --> Exception: Call to a member function select_product_info_by_product_id() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Cart.php 25
ERROR - 2020-04-01 18:53:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 18:57:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:05:22 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:22:12 --> Severity: error --> Exception: Call to a member function total_items() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 126
ERROR - 2020-04-01 19:22:15 --> Severity: error --> Exception: Call to a member function total_items() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 126
ERROR - 2020-04-01 19:22:20 --> Severity: error --> Exception: Call to a member function total_items() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 126
ERROR - 2020-04-01 19:26:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:28:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:29:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:38:44 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:46 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:48 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:49 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:51 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:51 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:56 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:58 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:59 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:38:59 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:39:02 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:39:03 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:39:04 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:39:07 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:39:18 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:44:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:54:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:54:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:54:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 19:55:27 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:29 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:30 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:31 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:31 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:31 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:32 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:32 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:33 --> 404 Page Not Found: /index
ERROR - 2020-04-01 19:55:33 --> 404 Page Not Found: /index
ERROR - 2020-04-01 20:11:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:29:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:36:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:36:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:39:16 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 127
ERROR - 2020-04-01 20:42:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:42:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 20:45:07 --> 404 Page Not Found: /index
ERROR - 2020-04-01 21:00:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:07:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:13:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:14:05 --> 404 Page Not Found: /index
ERROR - 2020-04-01 21:14:06 --> 404 Page Not Found: /index
ERROR - 2020-04-01 21:14:06 --> 404 Page Not Found: /index
ERROR - 2020-04-01 21:16:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:16:11 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 21:16:11 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 21:19:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:24:54 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:24:54 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 21:24:54 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 21:25:08 --> 404 Page Not Found: /index
ERROR - 2020-04-01 21:25:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:25:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:25:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:29:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:31:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:32:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:33:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 21:35:52 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-01 22:44:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 23:14:10 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:11 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:12 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:12 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:14:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:16:13 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:16:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-01 23:33:20 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:33:23 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:33:23 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:33:23 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:33:24 --> 404 Page Not Found: /index
ERROR - 2020-04-01 23:33:24 --> 404 Page Not Found: /index
