<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-14 02:02:05 --> 404 Page Not Found: /index
ERROR - 2020-05-14 02:02:06 --> 404 Page Not Found: /index
ERROR - 2020-05-14 04:07:59 --> 404 Page Not Found: /index
ERROR - 2020-05-14 02:19:05 --> 404 Page Not Found: /index
ERROR - 2020-05-14 06:53:34 --> 404 Page Not Found: /index
ERROR - 2020-05-14 13:05:28 --> 404 Page Not Found: /index
ERROR - 2020-05-14 13:05:46 --> 404 Page Not Found: /index
ERROR - 2020-05-14 03:53:06 --> 404 Page Not Found: /index
ERROR - 2020-05-14 14:05:30 --> 404 Page Not Found: /index
ERROR - 2020-05-14 14:05:30 --> 404 Page Not Found: /index
ERROR - 2020-05-14 14:05:31 --> 404 Page Not Found: /index
ERROR - 2020-05-14 14:05:31 --> 404 Page Not Found: /index
ERROR - 2020-05-14 14:05:32 --> 404 Page Not Found: /index
ERROR - 2020-05-14 21:45:41 --> 404 Page Not Found: /index
