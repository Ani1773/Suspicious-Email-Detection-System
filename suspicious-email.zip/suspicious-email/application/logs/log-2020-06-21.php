<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-21 00:32:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 00:32:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 00:32:48 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:33:04 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:33:24 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:33:37 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:35:32 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:37:15 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:38:39 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:46:18 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:59:14 --> 404 Page Not Found: /index
ERROR - 2020-06-21 00:59:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 00:59:56 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:00:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:00:06 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135154.jpg
ERROR - 2020-06-21 01:00:06 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585309656.jpg
ERROR - 2020-06-21 01:19:24 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:24:21 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:24:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:28:20 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:28:58 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:29:32 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:40:51 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-06-21 01:42:09 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:42:09 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-06-21 01:42:16 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-06-21 01:43:10 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-06-21 01:43:14 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:46:39 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-06-21 01:48:47 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:48:57 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:49:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:49:35 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:53:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:53:10 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:53:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:53:54 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:54:14 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-06-21 01:54:17 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:54:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:55:42 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-06-21 01:55:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:55:55 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:56:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:57:07 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-06-21 01:57:10 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:57:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:57:49 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-06-21 01:57:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 01:58:22 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-06-21 01:58:26 --> 404 Page Not Found: /index
ERROR - 2020-06-21 01:58:26 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-06-21 01:58:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:00:45 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-06-21 02:00:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:01:01 --> 404 Page Not Found: /index
ERROR - 2020-06-21 02:01:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:01:43 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-06-21 02:01:46 --> 404 Page Not Found: /index
ERROR - 2020-06-21 02:03:55 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-06-21 02:03:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:04:08 --> 404 Page Not Found: /index
ERROR - 2020-06-21 02:04:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:04:28 --> 404 Page Not Found: ../modules/admin_panel/controllers/Work_culture/img
ERROR - 2020-06-21 02:04:34 --> 404 Page Not Found: /index
ERROR - 2020-06-21 02:04:54 --> 404 Page Not Found: ../modules/admin_panel/controllers/Work_culture/img
ERROR - 2020-06-21 02:05:13 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-06-21 02:05:13 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-21 02:05:16 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-06-21 02:05:18 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-21 02:05:57 --> 404 Page Not Found: ../modules/admin_panel/controllers/Gallery/img
ERROR - 2020-06-21 02:06:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:06:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:06:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:18:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:18:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:18:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:18:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 02:18:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:07:09 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:11:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:11:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:11:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:25:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:25:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:26:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:26:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:27:10 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-06-21 09:27:20 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:27:20 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-06-21 09:27:26 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-06-21 09:27:26 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-21 09:27:27 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-21 09:27:40 --> 404 Page Not Found: ../modules/admin_panel/controllers/Gallery/img
ERROR - 2020-06-21 09:27:48 --> Query error: Table 'metromart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-06-21 09:33:09 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:33:10 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:34:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:34:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:34:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 09:47:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:12:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:12:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:12:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:12:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:15:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:16:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:16:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:16:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:16:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:17:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:35:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:49:22 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:49:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:49:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:51:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:51:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:52:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 10:52:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:05:14 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:05:38 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:05:38 --> 404 Page Not Found: /index
ERROR - 2020-06-21 05:15:52 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:14 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:18 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:22 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:30 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:37 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:41 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:47 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:20:57 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:21:03 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:21:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:21:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:21:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:21:52 --> 404 Page Not Found: /index
ERROR - 2020-06-21 04:22:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:22:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:22:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:22:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:23:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:23:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:23:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:24:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 04:24:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-21 06:29:56 --> 404 Page Not Found: /index
ERROR - 2020-06-21 07:04:55 --> 404 Page Not Found: /index
ERROR - 2020-06-21 08:34:48 --> 404 Page Not Found: /index
ERROR - 2020-06-21 08:41:29 --> 404 Page Not Found: /index
ERROR - 2020-06-21 08:48:08 --> 404 Page Not Found: /index
ERROR - 2020-06-21 08:54:47 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:01:27 --> 404 Page Not Found: /index
ERROR - 2020-06-21 09:08:08 --> 404 Page Not Found: /index
ERROR - 2020-06-21 11:38:30 --> 404 Page Not Found: /index
ERROR - 2020-06-21 21:32:58 --> 404 Page Not Found: /index
ERROR - 2020-06-21 21:34:06 --> 404 Page Not Found: /index
ERROR - 2020-06-21 12:29:18 --> 404 Page Not Found: /index
ERROR - 2020-06-21 18:54:22 --> 404 Page Not Found: /index
ERROR - 2020-06-21 18:54:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
