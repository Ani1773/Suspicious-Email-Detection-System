<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-24 02:16:59 --> 404 Page Not Found: /index
ERROR - 2020-06-24 02:51:09 --> 404 Page Not Found: /index
ERROR - 2020-06-24 11:10:42 --> 404 Page Not Found: /index
ERROR - 2020-06-24 11:10:44 --> 404 Page Not Found: /index
ERROR - 2020-06-24 11:42:48 --> 404 Page Not Found: /index
ERROR - 2020-06-24 11:42:48 --> 404 Page Not Found: /index
ERROR - 2020-06-24 11:42:48 --> 404 Page Not Found: /index
ERROR - 2020-06-24 15:26:54 --> 404 Page Not Found: /index
ERROR - 2020-06-24 22:15:41 --> 404 Page Not Found: /index
ERROR - 2020-06-24 22:15:42 --> 404 Page Not Found: /index
ERROR - 2020-06-24 22:20:55 --> 404 Page Not Found: /index
ERROR - 2020-06-24 22:07:25 --> 404 Page Not Found: /index
ERROR - 2020-06-24 22:07:30 --> 404 Page Not Found: /index
