<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-27 09:50:13 --> 404 Page Not Found: /index
ERROR - 2020-06-27 14:06:26 --> 404 Page Not Found: /index
ERROR - 2020-06-27 14:07:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-27 08:41:10 --> 404 Page Not Found: /index
ERROR - 2020-06-27 08:41:10 --> 404 Page Not Found: /index
ERROR - 2020-06-27 06:56:45 --> 404 Page Not Found: /index
ERROR - 2020-06-27 09:57:03 --> 404 Page Not Found: /index
ERROR - 2020-06-27 21:06:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
