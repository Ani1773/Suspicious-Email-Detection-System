<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-22 06:02:16 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:16 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:17 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:17 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:17 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:18 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:18 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:19 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:19 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:20 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:20 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:21 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:21 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:21 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:22 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:22 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:23 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:23 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:24 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:24 --> 404 Page Not Found: /index
ERROR - 2020-05-22 06:02:25 --> 404 Page Not Found: /index
ERROR - 2020-05-22 07:57:45 --> 404 Page Not Found: /index
ERROR - 2020-05-22 07:57:51 --> 404 Page Not Found: /index
ERROR - 2020-05-22 00:54:43 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 00:55:42 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 00:59:41 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 00:59:47 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 01:05:13 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 01:05:18 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 01:07:14 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-05-22 12:17:16 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:39:58 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:40:59 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:40:59 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:41:00 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:41:00 --> 404 Page Not Found: /index
ERROR - 2020-05-22 08:41:01 --> 404 Page Not Found: /index
ERROR - 2020-05-22 13:46:53 --> 404 Page Not Found: /index
ERROR - 2020-05-22 13:46:54 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-05-22 13:48:02 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-05-22 13:58:15 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-05-22 13:58:20 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 13:58:20 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-05-22 13:58:23 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 13:58:57 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 13:59:37 --> 404 Page Not Found: ../modules/admin_panel/controllers/Work_culture/img
ERROR - 2020-05-22 13:59:45 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-05-22 14:00:11 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-05-22 14:00:23 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-05-22 14:01:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:02:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:03:52 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-05-22 14:04:10 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-05-22 14:05:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:05:11 --> 404 Page Not Found: /index
ERROR - 2020-05-22 14:05:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:05:41 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-05-22 14:05:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:06:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 14:16:15 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-05-22 14:18:28 --> 404 Page Not Found: ../modules/admin_panel/controllers/Product/img
ERROR - 2020-05-22 14:18:54 --> 404 Page Not Found: ../modules/admin_panel/controllers/Category/img
ERROR - 2020-05-22 14:19:43 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 09:56:54 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:04:12 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:05:41 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:07:04 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:07:28 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:07:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 02:08:19 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:08:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 02:10:11 --> 404 Page Not Found: /index
ERROR - 2020-05-22 14:44:47 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:20:35 --> 404 Page Not Found: /index
ERROR - 2020-05-22 10:21:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 02:22:55 --> 404 Page Not Found: /index
ERROR - 2020-05-22 02:22:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 10:26:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:03:38 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 15:03:39 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-22 02:37:35 --> 404 Page Not Found: /index
ERROR - 2020-05-22 03:09:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 13:18:11 --> 404 Page Not Found: /index
ERROR - 2020-05-22 07:20:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 07:20:23 --> 404 Page Not Found: /index
ERROR - 2020-05-22 09:28:47 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 10:54:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 12:00:39 --> 404 Page Not Found: /index
ERROR - 2020-05-22 22:37:10 --> 404 Page Not Found: /index
ERROR - 2020-05-22 14:25:09 --> 404 Page Not Found: /index
ERROR - 2020-05-22 15:02:25 --> 404 Page Not Found: /index
ERROR - 2020-05-22 15:02:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-22 15:02:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
