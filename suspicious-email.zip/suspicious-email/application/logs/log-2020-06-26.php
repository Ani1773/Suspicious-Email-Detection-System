<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-26 09:08:27 --> 404 Page Not Found: /index
ERROR - 2020-06-26 20:20:10 --> 404 Page Not Found: /index
ERROR - 2020-06-26 20:22:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 20:22:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 20:22:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 20:22:59 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 08:33:49 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:37:02 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:43:12 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:43:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 08:43:13 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:43:27 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:43:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 08:43:41 --> 404 Page Not Found: /index
ERROR - 2020-06-26 08:43:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-06-26 08:43:42 --> 404 Page Not Found: /index
ERROR - 2020-06-26 14:09:26 --> 404 Page Not Found: /index
