<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-17 08:08:58 --> 404 Page Not Found: /index
ERROR - 2020-05-17 04:18:05 --> 404 Page Not Found: /index
ERROR - 2020-05-17 08:00:37 --> 404 Page Not Found: /index
ERROR - 2020-05-17 08:00:43 --> 404 Page Not Found: /index
ERROR - 2020-05-17 01:26:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-17 03:03:21 --> 404 Page Not Found: /index
ERROR - 2020-05-17 04:28:23 --> 404 Page Not Found: /index
ERROR - 2020-05-17 05:25:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-17 08:16:48 --> 404 Page Not Found: /index
ERROR - 2020-05-17 10:35:03 --> 404 Page Not Found: /index
ERROR - 2020-05-17 10:36:21 --> 404 Page Not Found: /index
ERROR - 2020-05-17 10:36:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-17 12:07:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-17 15:05:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-17 21:56:14 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
