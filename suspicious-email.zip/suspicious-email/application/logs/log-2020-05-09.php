<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-09 23:56:00 --> 404 Page Not Found: /index
