<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-06-02 06:29:30 --> 404 Page Not Found: /index
ERROR - 2020-06-02 08:03:19 --> 404 Page Not Found: /index
ERROR - 2020-06-02 08:03:24 --> 404 Page Not Found: /index
ERROR - 2020-06-02 09:05:19 --> 404 Page Not Found: /index
ERROR - 2020-06-02 12:10:56 --> 404 Page Not Found: /index
ERROR - 2020-06-02 11:16:13 --> 404 Page Not Found: /index
ERROR - 2020-06-02 11:16:14 --> 404 Page Not Found: /index
ERROR - 2020-06-02 11:16:15 --> 404 Page Not Found: /index
ERROR - 2020-06-02 16:14:58 --> 404 Page Not Found: /index
ERROR - 2020-06-02 14:54:08 --> 404 Page Not Found: /index
ERROR - 2020-06-02 21:25:09 --> 404 Page Not Found: /index
