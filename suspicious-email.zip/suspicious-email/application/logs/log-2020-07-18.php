<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-18 06:29:19 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:49:43 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:49:46 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-07-18 09:49:57 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:49:57 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-07-18 09:50:09 --> 404 Page Not Found: ../modules/admin_panel/controllers/Banner/img
ERROR - 2020-07-18 09:50:21 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:50:21 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-07-18 09:50:29 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-07-18 09:50:53 --> 404 Page Not Found: ../modules/admin_panel/controllers/Product/img
ERROR - 2020-07-18 01:15:42 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:31:11 --> 404 Page Not Found: /index
ERROR - 2020-07-18 09:31:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-18 03:11:06 --> 404 Page Not Found: /index
ERROR - 2020-07-18 00:35:19 --> 404 Page Not Found: /index
ERROR - 2020-07-18 02:11:03 --> 404 Page Not Found: /index
ERROR - 2020-07-18 06:00:38 --> 404 Page Not Found: /index
ERROR - 2020-07-18 13:42:09 --> 404 Page Not Found: /index
ERROR - 2020-07-18 16:27:14 --> 404 Page Not Found: /index
ERROR - 2020-07-18 18:30:07 --> 404 Page Not Found: /index
ERROR - 2020-07-18 18:30:07 --> 404 Page Not Found: /index
ERROR - 2020-07-18 11:35:46 --> 404 Page Not Found: /index
ERROR - 2020-07-18 11:35:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-18 14:38:28 --> 404 Page Not Found: /index
ERROR - 2020-07-18 21:56:34 --> 404 Page Not Found: /index
