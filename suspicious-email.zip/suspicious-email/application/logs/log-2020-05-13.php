<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-13 01:21:31 --> 404 Page Not Found: /index
ERROR - 2020-05-13 05:46:02 --> 404 Page Not Found: /index
ERROR - 2020-05-13 04:31:00 --> 404 Page Not Found: /index
ERROR - 2020-05-13 07:57:35 --> 404 Page Not Found: /index
ERROR - 2020-05-13 07:57:44 --> 404 Page Not Found: /index
ERROR - 2020-05-13 13:38:05 --> 404 Page Not Found: /index
ERROR - 2020-05-13 15:06:12 --> 404 Page Not Found: /index
ERROR - 2020-05-13 08:21:13 --> 404 Page Not Found: /index
ERROR - 2020-05-13 18:59:18 --> 404 Page Not Found: /index
ERROR - 2020-05-13 22:55:40 --> 404 Page Not Found: /index
