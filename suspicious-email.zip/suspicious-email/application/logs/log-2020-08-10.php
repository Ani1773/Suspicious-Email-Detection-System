<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-10 01:54:21 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:01:25 --> 404 Page Not Found: ../modules/admin_panel/controllers/Mail/img
ERROR - 2020-08-10 02:01:28 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:01:28 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:01:28 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:01:57 --> 404 Page Not Found: ../modules/admin_panel/controllers/Mail/img
ERROR - 2020-08-10 02:02:11 --> 404 Page Not Found: ../modules/admin_panel/controllers/Mail/img
ERROR - 2020-08-10 02:07:26 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:07:26 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:07:26 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:11:32 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:11:32 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:11:32 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:15:27 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:15:27 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:15:27 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:21:10 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:21:10 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:21:10 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:22:19 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:22:19 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:22:19 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:01 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:01 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:01 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:57 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:57 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:23:57 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:27:35 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:27:35 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:27:35 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:29:58 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:29:58 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:29:58 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:35:39 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:35:39 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:35:39 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:42:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'to LIKE's%'  order by id desc limit 0 , 50' at line 1 - Invalid query: SELECT * FROM mail_to_users where 1 AND to LIKE's%'  order by id desc limit 0 , 50
ERROR - 2020-08-10 02:42:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'to LIKE'ss%'  order by id desc limit 0 , 50' at line 1 - Invalid query: SELECT * FROM mail_to_users where 1 AND to LIKE'ss%'  order by id desc limit 0 , 50
ERROR - 2020-08-10 02:46:24 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:46:24 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:46:24 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:47:55 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:47:55 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:47:55 --> 404 Page Not Found: /index
ERROR - 2020-08-10 02:55:39 --> Query error: Table 'email.master_news' doesn't exist - Invalid query: select count(*) as total from master_news
ERROR - 2020-08-10 02:55:48 --> Query error: Table 'email.master_news' doesn't exist - Invalid query: select count(*) as total from master_news
ERROR - 2020-08-10 03:01:01 --> Query error: Table 'email.master_news' doesn't exist - Invalid query: select count(*) as total from master_news
ERROR - 2020-08-10 03:03:17 --> Query error: Table 'email.master_news' doesn't exist - Invalid query: select count(*) as total from master_news
ERROR - 2020-08-10 03:15:37 --> Query error: Table 'email.master_services' doesn't exist - Invalid query: select count(*) as total from master_services
ERROR - 2020-08-10 03:16:34 --> Query error: Table 'email.master_services' doesn't exist - Invalid query: select count(*) as total from master_services
ERROR - 2020-08-10 03:18:38 --> Query error: Table 'email.request_for_buy' doesn't exist - Invalid query: select count(*) as total from request_for_buy
ERROR - 2020-08-10 03:18:42 --> Query error: Table 'email.request_for_buy' doesn't exist - Invalid query: select count(*) as total from request_for_buy
ERROR - 2020-08-10 06:19:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
