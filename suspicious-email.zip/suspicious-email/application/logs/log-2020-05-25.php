<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-25 07:58:10 --> 404 Page Not Found: /index
ERROR - 2020-05-25 07:58:20 --> 404 Page Not Found: /index
ERROR - 2020-05-25 02:16:32 --> 404 Page Not Found: /index
ERROR - 2020-05-25 15:40:38 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-05-25 15:40:49 --> 404 Page Not Found: /index
ERROR - 2020-05-25 15:40:49 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-05-25 15:40:51 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-05-25 15:40:51 --> Query error: Table 'wowmart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-05-25 07:42:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-05-25 21:46:48 --> 404 Page Not Found: /index
ERROR - 2020-05-25 21:46:49 --> 404 Page Not Found: /index
ERROR - 2020-05-25 21:46:49 --> 404 Page Not Found: /index
