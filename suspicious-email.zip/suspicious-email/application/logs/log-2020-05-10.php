<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-05-10 09:57:09 --> 404 Page Not Found: /index
ERROR - 2020-05-10 02:05:37 --> 404 Page Not Found: /index
ERROR - 2020-05-10 14:43:49 --> 404 Page Not Found: /index
ERROR - 2020-05-10 14:43:56 --> 404 Page Not Found: /index
