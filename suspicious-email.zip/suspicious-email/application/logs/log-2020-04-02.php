<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-04-02 00:02:29 --> 404 Page Not Found: /index
ERROR - 2020-04-02 00:03:22 --> 404 Page Not Found: /index
ERROR - 2020-04-02 00:40:58 --> 404 Page Not Found: /index
ERROR - 2020-04-02 00:40:58 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:28 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:30 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:31 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:31 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:33 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:34 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:34 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:34 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:35 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:35 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:35 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:36 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:36 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:36 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:38 --> 404 Page Not Found: /index
ERROR - 2020-04-02 01:10:38 --> 404 Page Not Found: /index
ERROR - 2020-04-02 02:17:55 --> 404 Page Not Found: /index
ERROR - 2020-04-02 02:18:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 02:18:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 02:31:27 --> 404 Page Not Found: /index
ERROR - 2020-04-02 03:03:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 03:03:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 04:06:05 --> 404 Page Not Found: /index
ERROR - 2020-04-02 04:06:13 --> 404 Page Not Found: /index
ERROR - 2020-04-02 04:06:13 --> 404 Page Not Found: /index
ERROR - 2020-04-02 04:06:13 --> 404 Page Not Found: /index
ERROR - 2020-04-02 04:06:14 --> 404 Page Not Found: /index
ERROR - 2020-04-02 04:06:17 --> 404 Page Not Found: /index
ERROR - 2020-04-02 05:35:53 --> 404 Page Not Found: /index
ERROR - 2020-04-02 05:37:28 --> 404 Page Not Found: /index
ERROR - 2020-04-02 05:39:03 --> 404 Page Not Found: /index
ERROR - 2020-04-02 05:46:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 05:46:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 06:12:21 --> 404 Page Not Found: /index
ERROR - 2020-04-02 06:12:24 --> 404 Page Not Found: /index
ERROR - 2020-04-02 06:17:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 06:53:45 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:18:31 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '12345678')
ERROR - 2020-04-02 07:18:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:21:19 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:21:42 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '12345678')
ERROR - 2020-04-02 07:22:44 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:24:27 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:24:39 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:24:53 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:31:38 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:33:28 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:33:34 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('Sunil', 'sunil@gmail.com', '9643610584', '')
ERROR - 2020-04-02 07:35:48 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:35:56 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('dg', 'gdg@gmail.com', '9643610584', '12345678')
ERROR - 2020-04-02 07:37:58 --> Query error: Unknown column 'cus_name' in 'field list' - Invalid query: INSERT INTO `master_register` (`cus_name`, `cus_email`, `phone`, `cus_password`) VALUES ('dg', 'gdg@gmail.com', '9643610584', '12345678')
ERROR - 2020-04-02 07:38:00 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:38:05 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:38:49 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Checkout.php 24
ERROR - 2020-04-02 07:39:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:41:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:43:07 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:43:42 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:43:42 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:43:42 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:43:43 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:43:43 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:44:17 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:44:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:44:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:44:40 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:47:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:48:10 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:48:14 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:51:05 --> 404 Page Not Found: /index
ERROR - 2020-04-02 07:57:02 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 112
ERROR - 2020-04-02 07:57:57 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 112
ERROR - 2020-04-02 07:57:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:57:58 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting end of file /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/views/global/header.php 112
ERROR - 2020-04-02 07:58:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 07:58:26 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:03:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:03:40 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:04:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:04:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:04:21 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:09:28 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:09:34 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:12:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:15:41 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:15:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:17:23 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:17:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:17:40 --> Severity: error --> Exception: Call to a member function mail_send() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Checkout.php 46
ERROR - 2020-04-02 08:17:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:17:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 08:57:52 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:57:53 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:57:55 --> 404 Page Not Found: /index
ERROR - 2020-04-02 08:58:00 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:11:57 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:11:59 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:11:59 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:11:59 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:11:59 --> 404 Page Not Found: /index
ERROR - 2020-04-02 09:19:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 09:19:17 --> 404 Page Not Found: /index
ERROR - 2020-04-02 10:17:06 --> 404 Page Not Found: /index
ERROR - 2020-04-02 10:31:56 --> 404 Page Not Found: /index
ERROR - 2020-04-02 10:33:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:33:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:34:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:37:22 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:44:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:44:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 10:49:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:00:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:00:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:00:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:00:39 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 11:01:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:01:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:11:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:11:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:13:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:14:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:14:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:14:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:14:21 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 11:17:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:17:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:31:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:39:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:39:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:41:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:42:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:42:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:43:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:15 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:46:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:44 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:46:47 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:46:48 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:47:07 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:47:07 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:48:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:48:26 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:51:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:51:03 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 11:51:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 11:51:18 --> Query error: Table 'hyperpla_mart.tbl_product' doesn't exist - Invalid query: UPDATE tbl_product, tbl_order_details
		SET tbl_product.pro_quantity = tbl_product.pro_quantity - tbl_order_details.sales_quantity 
		WHERE tbl_product.pro_id = tbl_order_details.product_id 
		AND tbl_order_details.order_id = '0'
ERROR - 2020-04-02 11:52:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:00:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:00:18 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 12:00:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:00:23 --> Severity: error --> Exception: Call to a member function Order_success_mail_send() on null /home/hyperpla/public_html/hypersupermarket.in/application/modules/web_panel/controllers/Checkout.php 166
ERROR - 2020-04-02 12:04:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:23:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:23:28 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 12:23:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:25:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:10 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 12:33:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:38 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135154.jpg
ERROR - 2020-04-02 12:33:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:33:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:34:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:34:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:34:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:34:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:04 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 12:35:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:19 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 12:35:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:35:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 12:50:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 13:19:07 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:09:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:10:04 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:10:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:10:13 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:10:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:10:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:10:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:11:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:12:45 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 14:13:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:13:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:14:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:16:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:16:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:16:17 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:16:17 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:16:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:16:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:17:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:20:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:20:36 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:20:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:20:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:21:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:22:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:22:14 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:23:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:23:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:23:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:23:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:24:37 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:24:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:24:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:24:52 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 14:25:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:34:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:45:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:45:59 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:55:48 --> 404 Page Not Found: /index
ERROR - 2020-04-02 14:55:52 --> 404 Page Not Found: /index
ERROR - 2020-04-02 14:56:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:58:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 14:59:55 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:00:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:00:54 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:01:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:01:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:01:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:01:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:01:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:02:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:02:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:02:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:02:58 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585132082.jpg
ERROR - 2020-04-02 15:02:58 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 15:02:58 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:06:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:06:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:07:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:07:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:07:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:07:16 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 15:07:16 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585132082.jpg
ERROR - 2020-04-02 15:07:16 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:09:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:09:15 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 15:09:15 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585132082.jpg
ERROR - 2020-04-02 15:09:15 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:09:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:09:45 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585132082.jpg
ERROR - 2020-04-02 15:09:45 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 15:09:45 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:10:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:10:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:10:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:10:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:10:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:10:44 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585207628.jpg
ERROR - 2020-04-02 15:10:44 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585132082.jpg
ERROR - 2020-04-02 15:10:44 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:11:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:11:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:25 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:34 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-04-02 15:15:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:15:51 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585312310.jpg
ERROR - 2020-04-02 15:16:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:16:10 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:19:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:20:00 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:25:21 --> 404 Page Not Found: /index
ERROR - 2020-04-02 15:33:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:33:20 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135475.jpeg
ERROR - 2020-04-02 15:33:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:33:29 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135475.jpeg
ERROR - 2020-04-02 15:33:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:33:33 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135475.jpeg
ERROR - 2020-04-02 15:43:17 --> 404 Page Not Found: /index
ERROR - 2020-04-02 15:44:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:11 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135475.jpeg
ERROR - 2020-04-02 15:44:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:19 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585135475.jpeg
ERROR - 2020-04-02 15:44:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:28 --> 404 Page Not Found: ../modules/web_panel/controllers/Checkout/1585135475.jpeg
ERROR - 2020-04-02 15:44:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:44 --> 404 Page Not Found: /index
ERROR - 2020-04-02 15:44:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:44:52 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:46:21 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:46:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:46:32 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 15:46:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:12:05 --> 404 Page Not Found: /index
ERROR - 2020-04-02 16:12:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:16:24 --> 404 Page Not Found: /index
ERROR - 2020-04-02 16:16:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:16:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:32:01 --> 404 Page Not Found: /index
ERROR - 2020-04-02 16:40:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:48:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:48:59 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 16:49:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 17:01:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 17:08:20 --> 404 Page Not Found: /index
ERROR - 2020-04-02 17:23:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 17:23:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 17:43:57 --> 404 Page Not Found: /index
ERROR - 2020-04-02 18:25:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 18:30:32 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:13 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:14 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:16 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:16 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:20 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:21 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:21 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:22 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:22 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:23 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:23 --> 404 Page Not Found: /index
ERROR - 2020-04-02 19:46:25 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:26:49 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:14 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:16 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:17 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:19 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:19 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:19 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:19 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:43:20 --> 404 Page Not Found: /index
ERROR - 2020-04-02 21:54:18 --> 404 Page Not Found: /index
ERROR - 2020-04-02 22:02:45 --> 404 Page Not Found: /index
ERROR - 2020-04-02 22:55:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 22:55:08 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-04-02 23:29:11 --> 404 Page Not Found: /index
ERROR - 2020-04-02 23:30:59 --> 404 Page Not Found: /index
ERROR - 2020-04-02 23:31:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
