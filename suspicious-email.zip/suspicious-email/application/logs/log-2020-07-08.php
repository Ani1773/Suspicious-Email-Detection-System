<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-08 02:03:55 --> 404 Page Not Found: /index
ERROR - 2020-07-08 00:56:59 --> 404 Page Not Found: /index
ERROR - 2020-07-08 05:52:34 --> 404 Page Not Found: /index
ERROR - 2020-07-08 06:06:12 --> 404 Page Not Found: /index
ERROR - 2020-07-08 06:09:02 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-08 06:53:16 --> 404 Page Not Found: /index
ERROR - 2020-07-08 15:06:36 --> 404 Page Not Found: /index
ERROR - 2020-07-08 15:06:37 --> 404 Page Not Found: /index
ERROR - 2020-07-08 08:18:19 --> 404 Page Not Found: /index
ERROR - 2020-07-08 08:49:34 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:27:45 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:31:29 --> Severity: error --> Exception: Call to undefined function pre() /home/pmrx4tetwxuc/public_html/metromart.co.in/application/modules/web_panel/controllers/Our_team.php 11
ERROR - 2020-07-08 23:31:29 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:36:43 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:59:34 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-07-08 23:59:42 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:59:43 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-07-08 23:59:45 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-07-08 18:22:15 --> 404 Page Not Found: /index
ERROR - 2020-07-08 23:16:46 --> 404 Page Not Found: /index
