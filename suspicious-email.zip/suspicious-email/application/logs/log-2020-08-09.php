<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-08-09 07:12:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:13:15 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:13:31 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-08-09 07:26:47 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:27:32 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:27:32 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:34:34 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:42:11 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:42:12 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-08-09 07:42:40 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-08-09 07:45:13 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:45:15 --> 404 Page Not Found: ../modules/admin_panel/controllers/Contact/img
ERROR - 2020-08-09 07:45:51 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:46:13 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:46:45 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-08-09 07:51:29 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-08-09 07:53:24 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-08-09 07:53:29 --> 404 Page Not Found: /index
ERROR - 2020-08-09 07:53:30 --> 404 Page Not Found: ../modules/admin_panel/controllers/Profile/img
ERROR - 2020-08-09 07:55:05 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:33:18 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:33:18 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:33:18 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:34:23 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:34:23 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:34:23 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:41:39 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:41:39 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:41:39 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:44:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:44:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:44:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:45:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:45:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:45:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:48:15 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:48:15 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:48:15 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:48:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 08:48:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 08:49:25 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:49:25 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:49:25 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:50:01 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:50:01 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:50:01 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:50:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 08:58:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:02:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:02:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:02:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:03:50 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:03:50 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:03:50 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:05:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:05:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:05:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:05:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:05:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:05:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:07:29 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:07:29 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:07:29 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:07:47 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:10:51 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:10:52 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:10:52 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:03 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:03 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:03 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:09 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:11:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:11:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:13:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:13:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:13:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:13:54 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:13:54 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:15:57 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:15:58 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:16:19 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-08-09 09:17:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:17:22 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:18:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:18:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:20:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:20:19 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:51:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:51:18 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:58:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:58:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:58:22 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:58:22 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:58:22 --> 404 Page Not Found: /index
ERROR - 2020-08-09 09:58:24 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:58:26 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 09:58:27 --> Severity: error --> Exception: Call to undefined method Register::customer_login() E:\xampp\htdocs\email\application\modules\web_panel\controllers\Register.php 45
ERROR - 2020-08-09 10:01:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:01:29 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:01:30 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:01:30 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:01:40 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:01:41 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:01:44 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:02:10 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:02:43 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:02:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:02:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:04:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:05:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:05:11 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:12:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:25:12 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:25:34 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:25:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:27:06 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:27:29 --> Query error: Unknown column 'dob' in 'field list' - Invalid query: UPDATE `users` SET `first_name` = 'Bhanu', `last_name` = 'Gaund', `email` = 'sunil@appsquadz.com', `mobile` = '9643610584', `dob` = '2020-08-13', `gender` = '0', `address` = 'gdcffg', `modified` = 1596961649
WHERE `id` = '11'
ERROR - 2020-08-09 10:28:50 --> Query error: Unknown column 'address' in 'field list' - Invalid query: UPDATE `users` SET `first_name` = 'Bhanu', `last_name` = 'Gaund', `email` = 'sunil@appsquadz.com', `mobile` = '9643610584', `dob` = '2020-08-13', `gender` = '0', `address` = 'gdcffg', `modified` = 1596961730
WHERE `id` = '11'
ERROR - 2020-08-09 10:29:58 --> Query error: Unknown column 'modified' in 'field list' - Invalid query: UPDATE `users` SET `first_name` = 'Bhanu', `last_name` = 'Gaund', `email` = 'sunil@appsquadz.com', `mobile` = '9643610584', `dob` = '2020-08-13', `gender` = '0', `address` = 'gdcffg', `modified` = 1596961798
WHERE `id` = '11'
ERROR - 2020-08-09 10:30:40 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:32:27 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:34:06 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:35:17 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:36:07 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:36:14 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:38:23 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:38:28 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:38:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:38:46 --> 404 Page Not Found: /index
ERROR - 2020-08-09 08:40:38 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:41:02 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:41:44 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:41:53 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:42:08 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
ERROR - 2020-08-09 10:42:54 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:44:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:50:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:50:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:50:49 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:51:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 10:51:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:51:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:51:59 --> 404 Page Not Found: /index
ERROR - 2020-08-09 10:56:14 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
ERROR - 2020-08-09 10:59:49 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
ERROR - 2020-08-09 11:15:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:25:47 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:28:03 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-08-09 12:28:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:29:24 --> 404 Page Not Found: ../modules/web_panel/controllers//index
ERROR - 2020-08-09 12:31:15 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:31:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:32:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:32:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:34:29 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:36:12 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:36:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:36:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:37:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-08-09 12:37:50 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
