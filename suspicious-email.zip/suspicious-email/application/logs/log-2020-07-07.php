<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-07 00:05:12 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-07-07 00:05:21 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:05:21 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-07-07 00:05:23 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-07-07 00:05:36 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:05:36 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-07-07 00:05:44 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:05:44 --> 404 Page Not Found: ../modules/admin_panel/controllers/Work_culture/img
ERROR - 2020-07-07 00:05:52 --> 404 Page Not Found: ../modules/admin_panel/controllers/Support/img
ERROR - 2020-07-07 00:05:57 --> 404 Page Not Found: ../modules/admin_panel/controllers/Gallery/img
ERROR - 2020-07-07 00:06:12 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:06:12 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-07-07 00:17:51 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-07-07 00:19:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:09 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:25 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-07-07 00:19:25 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:25 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:25 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:52 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:52 --> 404 Page Not Found: ../modules/admin_panel/controllers/Features/img
ERROR - 2020-07-07 00:19:55 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:55 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:19:55 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:21:34 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:21:34 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:21:34 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:22:28 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:22:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 00:24:51 --> 404 Page Not Found: ../modules/admin_panel/controllers/Category/img
ERROR - 2020-07-07 00:54:03 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:54:07 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:54:07 --> 404 Page Not Found: ../modules/admin_panel/controllers/Video/img
ERROR - 2020-07-07 00:54:37 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:58:13 --> 404 Page Not Found: ../modules/admin_panel/controllers/Video/list_video
ERROR - 2020-07-07 00:58:13 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:16:32 --> 404 Page Not Found: /index
ERROR - 2020-07-07 08:13:44 --> 404 Page Not Found: /index
ERROR - 2020-07-07 09:08:45 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:09:49 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-07-07 12:09:49 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:09:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:09:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:14:02 --> 404 Page Not Found: ../modules/admin_panel/controllers/Team/img
ERROR - 2020-07-07 12:14:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:14:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:14:03 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:14:17 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:15:27 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:15:27 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:15:36 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:16:34 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:17:02 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:21:52 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:22:41 --> 404 Page Not Found: ../modules/admin_panel/controllers/Video/img
ERROR - 2020-07-07 12:28:03 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:28:08 --> 404 Page Not Found: ../modules/admin_panel/controllers/Video/img
ERROR - 2020-07-07 12:28:23 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:29:12 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:29:21 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:29:41 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:30:21 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:30:46 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:32:20 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:33:42 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:34:39 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:36:43 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:40:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:40:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:40:06 --> 404 Page Not Found: ../modules/web_panel/controllers/Cart/1585309656.jpg
ERROR - 2020-07-07 12:49:48 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:50:16 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:50:23 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:50:28 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:50:43 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-07-07 12:50:47 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-07-07 12:50:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:51:32 --> 404 Page Not Found: ../modules/admin_panel/controllers/Our_business/img
ERROR - 2020-07-07 12:51:44 --> 404 Page Not Found: ../modules/admin_panel/controllers/Vision_mision/img
ERROR - 2020-07-07 12:55:38 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 12:55:54 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-07-07 12:55:59 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:56:00 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-07-07 13:01:41 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_business/img
ERROR - 2020-07-07 13:01:52 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-07-07 13:01:59 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 13:02:01 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 13:02:13 --> 404 Page Not Found: /index
ERROR - 2020-07-07 13:04:15 --> 404 Page Not Found: ../modules/admin_panel/controllers/Franchise_process/img
ERROR - 2020-07-07 13:21:53 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 13:22:13 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 00:58:39 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:58:48 --> 404 Page Not Found: /index
ERROR - 2020-07-07 00:59:32 --> 404 Page Not Found: /index
ERROR - 2020-07-07 01:02:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 01:02:50 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 01:41:17 --> 404 Page Not Found: /index
ERROR - 2020-07-07 16:25:16 --> 404 Page Not Found: /index
ERROR - 2020-07-07 10:46:16 --> 404 Page Not Found: /index
ERROR - 2020-07-07 17:46:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 10:47:08 --> 404 Page Not Found: /index
ERROR - 2020-07-07 10:47:09 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:12:49 --> 404 Page Not Found: /index
ERROR - 2020-07-07 12:52:50 --> 404 Page Not Found: /index
ERROR - 2020-07-07 16:28:26 --> 404 Page Not Found: /index
ERROR - 2020-07-07 16:42:45 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-07-07 23:26:18 --> 404 Page Not Found: /index
ERROR - 2020-07-07 23:26:19 --> 404 Page Not Found: /index
ERROR - 2020-07-07 23:26:20 --> 404 Page Not Found: /index
ERROR - 2020-07-07 18:56:16 --> 404 Page Not Found: /index
ERROR - 2020-07-07 18:56:51 --> 404 Page Not Found: /index
ERROR - 2020-07-07 23:04:36 --> 404 Page Not Found: /index
