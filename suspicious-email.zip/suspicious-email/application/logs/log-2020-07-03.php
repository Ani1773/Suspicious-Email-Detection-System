<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-07-03 03:59:59 --> 404 Page Not Found: /index
ERROR - 2020-07-03 13:35:56 --> 404 Page Not Found: /index
ERROR - 2020-07-03 08:08:54 --> 404 Page Not Found: /index
ERROR - 2020-07-03 08:08:55 --> 404 Page Not Found: /index
ERROR - 2020-07-03 10:23:53 --> 404 Page Not Found: /index
ERROR - 2020-07-03 23:27:36 --> 404 Page Not Found: /index
ERROR - 2020-07-03 20:14:20 --> 404 Page Not Found: /index
ERROR - 2020-07-03 20:14:20 --> 404 Page Not Found: /index
ERROR - 2020-07-03 20:20:11 --> 404 Page Not Found: /index
