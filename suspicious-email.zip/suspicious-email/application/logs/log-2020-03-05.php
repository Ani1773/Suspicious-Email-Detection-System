<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-03-05 13:45:56 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-03-05 13:46:08 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:46:09 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-03-05 13:46:16 --> 404 Page Not Found: ../modules/admin_panel/controllers/Category/img
ERROR - 2020-03-05 13:46:17 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:46:27 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:50:26 --> 404 Page Not Found: /index
ERROR - 2020-03-05 03:46:46 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 01:02:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:33:05 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:33:12 --> 404 Page Not Found: ../modules/admin_panel/controllers/Login/img
ERROR - 2020-03-05 14:33:26 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:33:26 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-03-05 14:33:46 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
ERROR - 2020-03-05 14:34:37 --> 404 Page Not Found: ../modules/admin_panel/controllers/About/img
ERROR - 2020-03-05 14:38:26 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-03-05 14:38:26 --> 404 Page Not Found: ../modules/admin_panel/controllers/Users/img
ERROR - 2020-03-05 04:08:56 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:38:58 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:39:05 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 14:39:23 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-03-05 14:39:26 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-03-05 04:12:03 --> 404 Page Not Found: /index
ERROR - 2020-03-05 04:12:05 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:49:41 --> 404 Page Not Found: ../modules/admin_panel/controllers/Gallery/img
ERROR - 2020-03-05 14:49:59 --> 404 Page Not Found: ../modules/admin_panel/controllers/Configuration/img
ERROR - 2020-03-05 14:50:26 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-03-05 14:50:28 --> Query error: Table 'hyperpla_mart.conatct' doesn't exist - Invalid query: SELECT count(id) as total FROM conatct where user_type=1
ERROR - 2020-03-05 14:53:03 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 14:53:51 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 15:00:57 --> 404 Page Not Found: ../modules/admin_panel/controllers/Admin/img
ERROR - 2020-03-05 01:39:03 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:42 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:44 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:47 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:48 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:48 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:49 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:49 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:50 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:51 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:53 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:53 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:54 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:55 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:55 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:58 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:59 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:13:59 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:02 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:02 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:03 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:04 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:04 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:14:05 --> 404 Page Not Found: /index
ERROR - 2020-03-05 15:56:02 --> 404 Page Not Found: /index
ERROR - 2020-03-05 15:58:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 16:09:39 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 16:15:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 13:52:54 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:29:09 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 16:48:52 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:49:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:49:46 --> 404 Page Not Found: ../modules/admin_panel/controllers//index
ERROR - 2020-03-05 14:27:42 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 12:29:26 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:29:30 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:29:31 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:29:31 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:29:32 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:29:33 --> 404 Page Not Found: /index
ERROR - 2020-03-05 03:37:46 --> 404 Page Not Found: /index
ERROR - 2020-03-05 06:50:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 06:50:36 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 12:53:53 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:29:27 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 17:29:48 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 04:11:26 --> 404 Page Not Found: /index
ERROR - 2020-03-05 04:41:03 --> 404 Page Not Found: /index
ERROR - 2020-03-05 18:14:20 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 18:14:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 08:54:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 09:17:33 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 09:17:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 09:17:34 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 17:28:13 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:40 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:44 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:46 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:06:53 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:04 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:05 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:06 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:06 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:07 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:08 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:08 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:09 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:09 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:10 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:10 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:11 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:11 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:12 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:12 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:13 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:10:14 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:17:55 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:17:59 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:18:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:18:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:18:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:18:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 11:23:44 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 17:28:10 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:14 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:15 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:15 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:16 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:16 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:17 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:18 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:18 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:19 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:19 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:20 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:20 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:21 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:21 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:22 --> 404 Page Not Found: /index
ERROR - 2020-03-05 17:28:22 --> 404 Page Not Found: /index
ERROR - 2020-03-05 12:55:35 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 13:14:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:19 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:21 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:24 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:25 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:26 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:27 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:28 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:29 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:30 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:34 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:35 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:36 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:37 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:38 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:39 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:40 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:43 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:44 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:46 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:47 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:15:58 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:16:04 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:16:13 --> 404 Page Not Found: /index
ERROR - 2020-03-05 13:16:19 --> 404 Page Not Found: /index
ERROR - 2020-03-05 14:29:06 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 14:29:49 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 20:48:29 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:31 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:33 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:35 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:35 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:36 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:36 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:37 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:38 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:48:38 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:02 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:03 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:04 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:06 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:07 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:07 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:08 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:09 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:09 --> 404 Page Not Found: /index
ERROR - 2020-03-05 19:54:10 --> 404 Page Not Found: /index
ERROR - 2020-03-05 16:04:49 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:36 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:38 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:40 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:42 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:43 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:44 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:44 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:45 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:46 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:46 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:49 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:50 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:50 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:51 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:52 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:52 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:53 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:54 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:55 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:55 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:56 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:57 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:58 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:58 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:00:59 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:01:00 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:01:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:01:01 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:01:02 --> 404 Page Not Found: /index
ERROR - 2020-03-05 21:04:30 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 21:04:31 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
ERROR - 2020-03-05 21:46:47 --> 404 Page Not Found: /index
ERROR - 2020-03-05 20:37:09 --> 404 Page Not Found: /index
ERROR - 2020-03-05 23:38:17 --> Module controller failed to run: web_panel/User_panel_ini/user_ini
